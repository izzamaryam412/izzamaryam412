import 'package:college_app/Loginpage.dart';
import 'package:flutter/material.dart';
import 'dart:ui'; // Required for BackdropFilter

class Submit extends StatefulWidget {
  @override
  _SubmitState createState() => _SubmitState();
}

class _SubmitState extends State<Submit> with SingleTickerProviderStateMixin {
  late AnimationController _animationController;
  late Animation<Offset> _animation;

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      duration: const Duration(seconds: 1),
      vsync: this,
    )..forward();

    _animation = Tween<Offset>(
      begin: Offset(0, -1),
      end: Offset.zero,
    ).animate(CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeOut,
    ));
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [
                Color(0xff1b9bda),
                Color.fromARGB(255, 101, 8, 117),// Second color
              ],
              begin: Alignment.topLeft,           // Start position of the gradient
              end: Alignment.topRight,         // End position of the gradient
            ),
          ),
          child: Center(
            child: SlideTransition(
              position: _animation,
              child: Card(
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(15),
                ),
                child: Container(
                  width: 300,
                  padding: const EdgeInsets.all(20.0),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment:
                        CrossAxisAlignment.center, // Center align all children
                    children: [
                      Text(
                        'Thank You!',
                        style: TextStyle(
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                          color: Colors.deepOrange,
                        ),
                        textAlign: TextAlign.center, // Center align text
                      ),
                      SizedBox(height: 20),
                      RichText(
                        textAlign: TextAlign.center, // Center align text
                        text: TextSpan(
                          style: TextStyle(
                            fontSize: 20,
                            color: Color(0xff1b9bda),
                            fontWeight: FontWeight.w500,
                          ),
                          children: <TextSpan>[
                            TextSpan(
                              text:
                                  'You have submitted your admission form.We will inform you about your\n',
                            ),
                            TextSpan(
                              text: 'application through your mail.',
                            ),
                          ],
                        ),
                      ),
                      SizedBox(height: 30),
                      Container(
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [
                              Color(0xff1b9bda),
                              Color.fromARGB(255, 101, 8, 117),// Second color
                            ],
                            begin: Alignment.topLeft,           // Start position of the gradient
                            end: Alignment.topRight,         // End position of the gradient
                          ),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: ElevatedButton(
                          onPressed: () {
                            Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => Loginpage()));
                          },
                          style: ElevatedButton.styleFrom(
                             backgroundColor: Colors.transparent,
                            shadowColor: Colors.transparent,
                            padding: EdgeInsets.symmetric(
                                vertical: 10, horizontal: 20),
                          ),
                          child: Text(
                            'Login',
                            style: TextStyle(
                              color: Colors.white,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }
}
