import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class EventT extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          title: Text(
            'Event',
            style: TextStyle(color: Colors.white),
          ),
          backgroundColor: Color.fromARGB(255, 101, 8, 117),
          iconTheme: IconThemeData(
            color: Colors.white,
          ),
        ),
        body: Container(
          width: double.infinity,
          height: double.infinity,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [
                Color.fromARGB(255, 101, 8, 117).withOpacity(0.7),
                Colors.white.withOpacity(0.9),
              ],
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
            ),
          ),
          child: StreamBuilder(
            stream: FirebaseFirestore.instance.collection('T_events').snapshots(),
            builder: (context, AsyncSnapshot<QuerySnapshot> snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return Center(child: CircularProgressIndicator());
              }

              if (snapshot.hasError) {
                return Center(child: Text('Error: ${snapshot.error}'));
              }

              if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
                return Center(child: Text('No Events Available'));
              }

              // Build a list of EventCard widgets from the Firestore data
              return SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: snapshot.data!.docs.map((doc) {
                    return EventCard(
                      eventName: doc['name'],
                      eventDate: doc['date'],
                      eventDescription: doc['description'],
                      eventImage: doc['image'],
                    );
                  }).toList(),
                ),
              );
            },
          ),
        ),
      ),
    );
  }
}

class EventCard extends StatelessWidget {
  final String eventName;
  final String eventDate;
  final String eventDescription;
  final String eventImage;

  const EventCard({
    required this.eventName,
    required this.eventDate,
    required this.eventDescription,
    required this.eventImage,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Card(
        elevation: 5,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(15),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ClipRRect(
              borderRadius: BorderRadius.vertical(top: Radius.circular(15)),
              child: Image.network(
                eventImage,
                fit: BoxFit.cover,
                width: double.infinity,
                height: 200,
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(12.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    eventName,
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: Color.fromARGB(255, 101, 8, 117),
                    ),
                  ),
                  SizedBox(height: 8),
                  Text(
                    'Date: $eventDate',
                    style: TextStyle(
                      color: Color.fromARGB(255, 101, 8, 117),
                    ),
                  ),
                  SizedBox(height: 8),
                  Text(
                    eventDescription,
                    style: TextStyle(
                      fontSize: 16,
                      color: Color.fromARGB(255, 101, 8, 117),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
