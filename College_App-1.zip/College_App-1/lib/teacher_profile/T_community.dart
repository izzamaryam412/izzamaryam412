import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:college_app/teacher_profile/chat.dart';
import 'package:curved_navigation_bar/curved_navigation_bar.dart';

class CommunityT extends StatefulWidget {
  final String id;
  final String name;

  CommunityT({required this.id, required this.name});

  @override
  _CommunityTState createState() => _CommunityTState();
}

class _CommunityTState extends State<CommunityT> {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  Map<String, Map<String, dynamic>> departmentsWithData = {}; // Updated type

  @override
  void initState() {
    super.initState();
    fetchData();
  }

  Future<void> fetchData() async {
    try {
      const List<String> departments = ['IT', 'Economic', 'Islamiat'];
      final Map<String, Map<String, dynamic>> tempDepartments = {};

      for (String department in departments) {
        final QuerySnapshot studentsSnapshot = await _firestore
            .collection('Users')
            .doc(department)
            .collection('Students')
            .get();

        final int studentCount = studentsSnapshot.size;

        final QuerySnapshot teachersSnapshot = await _firestore
            .collection('Users')
            .doc(department)
            .collection('Teachers')
            .where('ID', isEqualTo: widget.id)
            .get();

        if (teachersSnapshot.docs.isNotEmpty) {
          final List<Map<String, dynamic>> studyGroups = [];
          for (var doc in teachersSnapshot.docs) {
            studyGroups.add(doc.data() as Map<String, dynamic>);
          }

          tempDepartments[department] = {
            'StudyGroups': studyGroups,
            'StudentCount': studentCount,
          };
        }
      }

      if (tempDepartments.isNotEmpty) {
        setState(() {
          departmentsWithData = tempDepartments;
        });
      } else {
        _showErrorDialog('No departments found with the specified teacher ID.');
      }
    } catch (e) {
      _showErrorDialog('Error fetching data: $e');
    }
  }

  void _showErrorDialog(String message) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Error'),
          content: Text(message),
          actions: <Widget>[
            TextButton(
              child: Text('OK'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }

  void _navigateToDepartment(
      String departmentName, String name, String id, int studentCount) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => GroupChatScreen(
          name: name,
          id: id,
          departmentName: departmentName,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          title: Center(
            child: Text(
              'Community',
              style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
            ),
          ),
          backgroundColor:  Color.fromARGB(255, 101, 8, 117),
          automaticallyImplyLeading: false,
        ),
        body: Container(
          width: double.infinity,
          height: double.infinity,
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: departmentsWithData.keys.map((departmentName) {
                final data = departmentsWithData[departmentName];
                final studyGroups =
                    data?['StudyGroups'] as List<Map<String, dynamic>>? ?? [];
                final studentCount = data?['StudentCount'] as int? ?? 0;

                return Padding(
                  padding: const EdgeInsets.all(12.0),
                  child: GestureDetector(
                    onTap: () => _navigateToDepartment(
                        departmentName, widget.name, widget.id, studentCount),
                    child: Container(
                      height: 100,
                      width: double.infinity,
                      decoration: BoxDecoration(
                        color:  Color.fromARGB(255, 101, 8, 117),
                        borderRadius: BorderRadius.circular(20),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.grey.withOpacity(0.3),
                            spreadRadius: 2,
                            blurRadius: 10,
                            offset: Offset(0, 3),
                          ),
                        ],
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: CircleAvatar(
                              radius: 40,
                              backgroundColor:
                                  Color.fromARGB(255, 230, 232, 233),
                              child: Icon(Icons.group,
                                  size: 50, color:  Color.fromARGB(255, 101, 8, 117)),
                            ),
                          ),
                          Expanded(
                            child: Padding(
                              padding: const EdgeInsets.only(top: 22, left: 10),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    departmentName,
                                    style: TextStyle(
                                      fontSize: 18,
                                      fontWeight: FontWeight.bold,
                                      color: Colors.white,
                                    ),
                                  ),
                                  Text(
                                    'Students :  $studentCount', // Display the student count
                                    style: TextStyle(
                                      fontSize: 14,
                                      color: Colors.white,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(right: 8.0),
                            child: Row(
                              children: [
                                Icon(Icons.arrow_forward_ios_sharp,
                                    size: 20, color: Colors.white),
                                Icon(Icons.arrow_forward_ios_sharp,
                                    size: 25, color: Colors.white),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                );
              }).toList(),
            ),
          ),
        ),
        bottomNavigationBar: CurvedNavigationBar(
          color:  Color.fromARGB(255, 101, 8, 117),
          backgroundColor: Colors.transparent,
          buttonBackgroundColor:  Color.fromARGB(255, 101, 8, 117),
          animationCurve: Curves.easeInOut,
          animationDuration: Duration(milliseconds: 600),
          items: <Widget>[
            Icon(Icons.home, size: 30, color: Colors.white),
            Icon(Icons.group, size: 30, color: Colors.white),
            Icon(Icons.notifications, size: 30, color: Colors.white),
          ],
        ),
      ),
    );
  }
}
