import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:college_app/Student_profile/GroupChatPage.dart';
import 'package:flutter/material.dart';

class Community extends StatefulWidget {
  final String id;
  final String name;
  final String department;

  Community({
    required this.id,
    required this.name,
    required this.department,
  });

  @override
  _CommunitySState createState() => _CommunitySState();
}

class _CommunitySState extends State<Community> {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  Map<String, int> departmentsWithStudentCount = {};

  @override
  void initState() {
    super.initState();
    fetchStudentData();
  }

  Future<void> fetchStudentData() async {
    try {
      const List<String> departments = ['IT', 'Economic', 'Islamiat'];
      final Map<String, int> tempDepartments = {};

      for (String department in departments) {
        final QuerySnapshot studentsSnapshot = await _firestore
            .collection('Users')
            .doc(department)
            .collection('Students')
            .get();

        final int studentCount = studentsSnapshot.size;
        tempDepartments[department] = studentCount;
      }

      // Correctly filter the map to include only the matching department
      if (tempDepartments.containsKey(widget.department)) {
        setState(() {
          departmentsWithStudentCount = {
            widget.department: tempDepartments[widget.department]!
          };
        });
      } else {
        setState(() {
          departmentsWithStudentCount = {};
        });
      }
    } catch (e) {
      _showErrorDialog('Error fetching student data: $e');
    }
  }

  void _showErrorDialog(String message) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Error'),
          content: Text(message),
          actions: <Widget>[
            TextButton(
              child: Text('OK'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          title: Center(
            child: Text(
              'Community',
              style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
            ),
          ),
          backgroundColor: Color(0xff1b9bda),
          automaticallyImplyLeading: false,
        ),
        body: Container(
          width: double.infinity,
          height: double.infinity,
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: departmentsWithStudentCount.keys.map((departmentName) {
                final studentCount =
                    departmentsWithStudentCount[departmentName] ?? 0;

                return Padding(
                  padding: const EdgeInsets.all(12.0),
                  child: GestureDetector(
                    onTap: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => GroupChatScreen(
                                    name: widget.name,
                                    id: widget.id,
                                    departmentName: widget.department,
                                  )));
                      // Add navigation or other action here
                    },
                    child: Container(
                      height: 100,
                      width: double.infinity,
                      decoration: BoxDecoration(
                        color: Color(0xff1b9bda),
                        borderRadius: BorderRadius.circular(20),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.grey.withOpacity(0.3),
                            spreadRadius: 2,
                            blurRadius: 10,
                            offset: Offset(0, 3),
                          ),
                        ],
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: CircleAvatar(
                              radius: 40,
                              backgroundColor:
                                  Color.fromARGB(255, 230, 232, 233),
                              child: Icon(Icons.group,
                                  size: 50, color: Color(0xff1b9bda)),
                            ),
                          ),
                          Expanded(
                            child: Padding(
                              padding: const EdgeInsets.only(top: 22, left: 10),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    departmentName,
                                    style: TextStyle(
                                      fontSize: 18,
                                      fontWeight: FontWeight.bold,
                                      color: Colors.white,
                                    ),
                                  ),
                                  Text(
                                    'Students: $studentCount',
                                    style: TextStyle(
                                      fontSize: 14,
                                      color: Colors.white,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(right: 8.0),
                            child: Row(
                              children: [
                                Icon(Icons.arrow_forward_ios_sharp,
                                    size: 20, color: Colors.white),
                                Icon(Icons.arrow_forward_ios_sharp,
                                    size: 25, color: Colors.white),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                );
              }).toList(),
            ),
          ),
        ),
      ),
    );
  }
}
