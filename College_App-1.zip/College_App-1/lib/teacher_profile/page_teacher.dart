import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';

import 'package:college_app/teacher_profile/EventT.dart';
import 'package:college_app/teacher_profile/semesterattendance.dart';
import 'package:curved_navigation_bar/curved_navigation_bar.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

import 'T_Courses.dart';
import 'T_community.dart';
import 'T_notification.dart';
import 'T_timetable.dart';

class TeacherPage extends StatefulWidget {
  final String name;
  final String id; // Ensure ID is a String
  final String department;
  TeacherPage({required this.id, required this.name, required this.department});

  @override
  _TeacherPageState createState() => _TeacherPageState();
}

class _TeacherPageState extends State<TeacherPage> {
  int _selectedIndex = 0;
  File? _image;
  String? _imageUrl;
  bool _isLoading = false; // Loading state variable
  final ImagePicker _imagePicker = ImagePicker();

  @override
  void initState() {
    super.initState();
    _fetchProfileImage(); // Fetch the profile image when the widget is initialized
  }

  Future<void> _uploadImage(File image) async {
    try {
      setState(() {
        _isLoading = true;
      });

      String userId = widget.id;
      String department = widget.department;
      String role = 'Teachers';

      // Construct the storage path including department and role
      final storageRef = FirebaseStorage.instance
          .ref()
          .child('images/$department/$role/$userId.jpg');

      // Upload the new image
      final uploadTask = storageRef.putFile(image);
      final snapshot = await uploadTask.whenComplete(() => {});
      final downloadUrl = await snapshot.ref.getDownloadURL();

      // Save image URL in Firestore
      await FirebaseFirestore.instance
          .collection('images')
          .doc(department)
          .collection(role)
          .doc(userId)
          .set({'imageUrl': downloadUrl}, SetOptions(merge: true));

      setState(() {
        _imageUrl = downloadUrl;
        _isLoading = false;
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Image uploaded successfully!')),
      );
    } catch (e) {
      setState(() {
        _isLoading = false;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to upload image: $e')),
      );
    }
  }

  Future<void> _fetchProfileImage() async {
    setState(() {
      _isLoading = true;
    });

    try {
      String userId = widget.id;
      String department = widget.department;
      String role = 'Teachers'; // Ensure this matches your Firestore structure

      DocumentSnapshot userDoc = await FirebaseFirestore.instance
          .collection('images')
          .doc(department)
          .collection(role)
          .doc(userId)
          .get();

      if (userDoc.exists) {
        setState(() {
          _imageUrl = userDoc.get('imageUrl') as String?;
          _isLoading = false;
        });
      } else {
        setState(() {
          _imageUrl = null;
          _isLoading = false;
        });
      }
    } catch (e) {
      print('Error fetching profile image: $e');
      setState(() {
        _isLoading = false;
      });
    }
  }

  Future<void> getImageFromGallery() async {
    final pickedFile =
        await _imagePicker.pickImage(source: ImageSource.gallery);
    setState(() {
      if (pickedFile != null) {
        _image = File(pickedFile.path);
        if (_image != null) {
          _uploadImage(_image!);
        }
      }
    });
  }

  Future<void> getImageFromCamera() async {
    final pickedFile = await _imagePicker.pickImage(source: ImageSource.camera);
    setState(() {
      if (pickedFile != null) {
        _image = File(pickedFile.path);
        if (_image != null) {
          _uploadImage(_image!);
        }
      }
    });
  }

  Future<void> showOptions() async {
    showCupertinoModalPopup(
      context: context,
      builder: (context) => CupertinoActionSheet(
        actions: [
          Container(
            color: Color(0xff1b9bda),
            child: CupertinoActionSheetAction(
              child: Text('Gallery', style: TextStyle(color: Colors.white)),
              onPressed: () {
                Navigator.of(context).pop();
                getImageFromGallery();
              },
            ),
          ),
          Container(
            color: Color(0xff1b9bda),
            child: CupertinoActionSheetAction(
              child: Text('Camera', style: TextStyle(color: Colors.white)),
              onPressed: () {
                Navigator.of(context).pop();
                getImageFromCamera();
              },
            ),
          ),
        ],
      ),
    );
  }

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
    _navigateToSelectedPage(index, widget.id, widget.name);
  }

  void _navigateToSelectedPage(int index, String id, String name) {
    Widget selectedPage;
    if (index == 1) {
      selectedPage = CommunityT(
        id: id,
        name: name,
      );// Teacher Community
    } else if (index == 2) {
      selectedPage = TNotification(); // Teacher Notifications
    } else {
      return;
    }

    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => selectedPage),
    ).then((_) {
      setState(() {
        _selectedIndex = 0;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: HomePage(
          department: widget.department,
          id: widget.id,
          name: widget.name,
          image: _image,
          onImagePick: (ImageSource source) => showOptions(),
          onImageUpload: () {
            if (_image != null) {
              _uploadImage(_image!);
            } else {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text('No image selected for upload.')),
              );
            }
          },
          imageUrl: _imageUrl,
          isLoading: _isLoading,
        ),
        bottomNavigationBar: CurvedNavigationBar(
          color:  Color.fromARGB(255, 101, 8, 117),
          backgroundColor: Colors.transparent,
          buttonBackgroundColor:  Color.fromARGB(255, 101, 8, 117),
          animationCurve: Curves.easeInOut,
          animationDuration: Duration(milliseconds: 600),
          items: <Widget>[
            Icon(Icons.home, size: 30, color: Colors.white),
            Icon(Icons.group, size: 30, color: Colors.white),
            Icon(Icons.notifications, size: 30, color: Colors.white),
          ],
          onTap: _onItemTapped,
        ),
      ),
    );
  }
}

class HomePage extends StatefulWidget {
  final String name;
  final String id;
  final File? image;
  final String? imageUrl;
  final String department;
  final Future<void> Function(ImageSource) onImagePick;
  final VoidCallback onImageUpload;
  final bool isLoading; // Add this line

  HomePage({
    required this.department,
    required this.id,
    required this.name,
    required this.image,
    required this.onImagePick,
    required this.onImageUpload,
    required this.imageUrl,
    required this.isLoading, // Add this line
  });

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  String? _imageUrl;

  // Call this method whenever the image is being uploaded
  void _startLoading() {
    setState(() {});
  }

  // Call this method when the image upload is completed
  void _stopLoading() {
    setState(() {});
  }

  Future<void> _deleteImage() async {
    try {
      setState(() {});

      String userId = widget.id;
      String department = widget.department;
      String role = 'Teachers';

      final storageRef = FirebaseStorage.instance
          .ref()
          .child('images/$department/$role/$userId.jpg');

      await storageRef.delete();
      print('Image deleted from Firebase Storage');

      await FirebaseFirestore.instance
          .collection('images')
          .doc(department)
          .collection(role)
          .doc(userId)
          .delete();

      print('Image data deleted from Firestore');

      setState(() {
        _imageUrl = null;
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Image deleted successfully!')),
      );
    } catch (e) {
      setState(() {});
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to delete image: $e')),
      );
    }
  }

  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          buildBackground(),
          Column(
            children: [
              Container(
                margin: EdgeInsets.only(top: 45, left: 40),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    GestureDetector(
                        onTap: () {
                          showDialog(
                            context: context,
                            builder: (context) => AlertDialog(
                              title: Text('Select Image'),
                              actions: [
                                TextButton(
                                  onPressed: () async {
                                    Navigator.pop(context);
                                    await _deleteImage();
                                  },
                                  child: Text('Delete',
                                      style: TextStyle(color: Colors.red)),
                                ),
                                TextButton(
                                  onPressed: () {
                                    Navigator.pop(context);
                                  },
                                  child: Text('Close'),
                                ),
                                TextButton(
                                  onPressed: () {
                                    Navigator.pop(context);
                                    widget.onImagePick(ImageSource.gallery);
                                  },
                                  child: Text('Update'),
                                ),
                              ],
                            ),
                          );
                        },
                        child: CircleAvatar(
                          radius: 55,
                          backgroundColor: Colors.grey[300],
                          child: widget.isLoading
                              ? CircularProgressIndicator()
                              : widget.imageUrl != null
                                  ? ClipOval(
                                      child: Image.network(
                                        '${widget.imageUrl}?timestamp=${DateTime.now().millisecondsSinceEpoch}',
                                        fit: BoxFit.cover,
                                        width: 110,
                                        height: 110,
                                        errorBuilder:
                                            (context, error, stackTrace) {
                                          print('Image load error: $error');
                                          return Icon(Icons.person,
                                              size: 60, color: Colors.white);
                                        },
                                      ),
                                    )
                                  : Icon(Icons.person,
                                      size: 60, color: Colors.white),
                        )),
                    Expanded(
                      child: Column(
                        children: [
                          Text(
                            'Name: ${widget.name}',
                            style: TextStyle(
                              fontSize: 20,
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          Text(
                            'Roll no: ${widget.id}',
                            style: TextStyle(
                              fontSize: 17,
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                            ),
                            textAlign: TextAlign.center,
                          ),
                          Text(
                            'Department: ${widget.department}',
                            style: TextStyle(
                              fontSize: 17,
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                            ),
                          )
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(height: 10),
              Expanded(
                child: SingleChildScrollView(
                  child: buildGrid(context),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget buildBackground() {
    return Container(
      width: double.infinity,
      height: double.infinity,
      color: Color(0xFFF0F8FF),
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.only(left: 8, right: 8),
            child: Container(
                height: 260,
                decoration: BoxDecoration(
                    color:  Color.fromARGB(255, 101, 8, 117),
                    borderRadius: BorderRadius.only(
                        bottomLeft: Radius.circular(50),
                        bottomRight: Radius.circular(50)),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.8), // Shadow color
                        blurRadius: 16, // Spread of the shadow
                        offset: Offset(0, 4),
                      )
                    ])),
          ),
        ],
      ),
    );
  }

  Widget buildGrid(BuildContext context) {
    return Container(
      padding: EdgeInsets.only(top: 160, left: 20, right: 20, bottom: 9),
      child: GridView.count(
        crossAxisCount: 2,
        crossAxisSpacing: 10,
        mainAxisSpacing: 10,
        shrinkWrap: true,
        physics: NeverScrollableScrollPhysics(),
        children: [
          buildGridItem(context, Icons.add_task, 'Attendance',
              SemesterAttendance(id: widget.id)),
          buildGridItem(context, Icons.event, 'Event', EventT()),
          buildGridItem(context, Icons.calendar_month, 'Courses', T_Courses()),
          buildGridItem(context, Icons.schedule, 'Timetable', TimetableDepartments()),
        ],
      ),
    );
  }

  Widget buildGridItem(
      BuildContext context, IconData icon, String title, Widget page) {
    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => page),
        );
      },
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(15),
          boxShadow: [
            BoxShadow(
              color: Colors.black26,
              blurRadius: 10,
              offset: Offset(0, 5),
            ),
          ],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color:  Color.fromARGB(255, 101, 8, 117), size: 50),
            Text(
              title,
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: Color.fromARGB(255, 101, 8, 117),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
