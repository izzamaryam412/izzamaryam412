import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class Courses extends StatefulWidget {
  final String department;

  Courses({required this.department});

  @override
  _CoursesStudentState createState() => _CoursesStudentState();
}

class _CoursesStudentState extends State<Courses> {
  final Map<String, List<Map<String, String>>> semesters = {
    'Semester 1': [],
    'Semester 2': [],
    'Semester 3': [],
    'Semester 4': [],
    'Semester 5': [],
    'Semester 6': [],
    'Semester 7': [],
    'Semester 8': [],
  };

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: SafeArea(
        child: Scaffold(
          appBar: AppBar(
            backgroundColor: Color(0xff1b9bda),
            title: Text(
              ' Courses - ${widget.department}',
              style: TextStyle(color: Colors.white),
            ),
            leading: IconButton(
              icon: Icon(Icons.arrow_back),
              color: Colors.white,
              onPressed: () {
                Navigator.pop(context); // Navigate back when pressed
              },
            ),
          ),
          body: SemesterView(
            semesters: semesters,
            department: widget.department,
          ),
        ),
      ),
    );
  }
}

class SemesterView extends StatelessWidget {
  final Map<String, List<Map<String, String>>> semesters;
  final String department;

  SemesterView({required this.semesters, required this.department});

  @override
  Widget build(BuildContext context) {
    List<String> semesterKeys = semesters.keys.toList();
    return SafeArea(
      child: Scaffold(
        body: ListView.builder(
          itemCount: semesterKeys.length,
          itemBuilder: (context, index) {
            String semester = semesterKeys[index];
            return Card(
              elevation: 5,
              shadowColor: Color(0xff1b9bda),
              margin: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              child: ListTile(
                title: Text(
                  semester,
                  style: TextStyle(
                      color:  Color(0xff1b9bda), fontWeight: FontWeight.bold),
                ),
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => SemesterSubjectsView(
                        semester: semester,
                        department: department,
                      ),
                    ),
                  );
                },
              ),
            );
          },
        ),
      ),
    );
  }
}

class SemesterSubjectsView extends StatelessWidget {
  final String semester;
  final String department;

  SemesterSubjectsView({required this.semester, required this.department});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: Color(0xff1b9bda),
          title: Text(
            '$department - $semester',
            style: TextStyle(color: Colors.white),
          ),
          iconTheme: IconThemeData(color: Colors.white),
        ),
        body: StreamBuilder<QuerySnapshot>(
          stream: FirebaseFirestore.instance
              .collection('Subjects')
              .doc(department)
              .collection(semester)
              .snapshots(),
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return Center(child: CircularProgressIndicator());
            }

            if (snapshot.hasError) {
              print('Error fetching subjects: ${snapshot.error}');
              return Center(child: Text('Error fetching subjects'));
            }

            if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
              return Center(child: Text('No subjects available.'));
            }

            List<DocumentSnapshot> subjects = snapshot.data!.docs;

            return ListView.builder(
              itemCount: subjects.length,
              itemBuilder: (context, index) {
                var subjectData = subjects[index].data() as Map<String, dynamic>;

                return Card(
                  elevation: 5,
                  shadowColor: Color(0xff1b9bda),
                  margin: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  child: ListTile(
                    title: Text(subjectData['name'] ?? 'No name',style: TextStyle(color: Color(0xff1b9bda),),),
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => SubjectView(
                            subject: subjectData['name'] ?? 'No name',
                            imagePath: subjectData['image'] ?? '',
                          ),
                        ),
                      );
                    },
                  ),
                );
              },
            );
          },
        ),
      ),
    );
  }
}

class SubjectView extends StatelessWidget {
  final String subject;
  final String imagePath;

  SubjectView({
    required this.subject,
    required this.imagePath,
  });

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          title: Text(subject, style: TextStyle(color: Colors.white)),
          backgroundColor: Color(0xff1b9bda),
          iconTheme: IconThemeData(
            color: Colors.white,
          ),
        ),
        body: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Expanded(
              child: imagePath.isNotEmpty
                  ? Image.network(
                imagePath,
                width: double.infinity,
                height: double.infinity,
                fit: BoxFit.contain,
              )
                  : Center(
                child: Text(
                  'No image available',
                  style: TextStyle(
                    fontSize: 18,
                    color: Color(0xff1b9bda),
                  ),
                ),
              ),
            ),
            SizedBox(height: 20),
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Text(
                subject,
                style: TextStyle(
                  color: Color(0xff1b9bda),
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
