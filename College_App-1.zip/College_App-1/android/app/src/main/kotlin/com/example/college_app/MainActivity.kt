package com.example.college_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
