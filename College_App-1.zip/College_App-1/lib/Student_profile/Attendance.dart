import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class Attendance extends StatefulWidget {
  final String department;
  final String id;

  Attendance({
    required this.department,
    required this.id,
  });

  @override
  _AttendancePageState createState() => _AttendancePageState();
}

class _AttendancePageState extends State<Attendance> {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  late Future<List<Map<String, dynamic>>> _attendanceRecords;

  @override
  void initState() {
    super.initState();
    _attendanceRecords = _fetchAttendanceRecords();
  }

  Future<List<Map<String, dynamic>>> _fetchAttendanceRecords() async {
    try {
      List<Map<String, dynamic>> records = [];

      // Fetch attendance records for the specific department and student ID
      QuerySnapshot attendanceSnapshot = await _firestore
          .collection('attendance')
          .doc(widget.department)
          .collection(widget.id)
          .get();

      for (DocumentSnapshot record in attendanceSnapshot.docs) {
        records.add({
          'ID': record['ID'],
          'status': record['status'],
          'studentId': record['studentId'],
          'timestamp': record['timestamp']?.toDate(),
        });
      }

      // Sort records by date (latest first) and status (Present before Absent)
      records.sort((a, b) {
        DateTime dateA = a['timestamp'] ?? DateTime.now();
        DateTime dateB = b['timestamp'] ?? DateTime.now();

        int dateComparison = dateB.compareTo(dateA);
        if (dateComparison != 0) return dateComparison;

        String statusA = a['status'] ?? '';
        String statusB = b['status'] ?? '';

        if (statusA == statusB) return 0;
        if (statusA == 'Present') return -1;
        if (statusB == 'Present') return 1;
        return 0;
      });

      return records;
    } catch (e) {
      print('Error fetching records: $e');
      return [];
    }
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          title:
              Text('Attendance - ${widget.department} (${widget.id})',style: TextStyle(color: Colors.white),),
          backgroundColor: Color(0xff1b9bda),
          iconTheme: IconThemeData(
            color: Colors.white,
          ),
        ),
        body: FutureBuilder<List<Map<String, dynamic>>>(
          future: _attendanceRecords,
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return Center(child: CircularProgressIndicator());
            }

            if (snapshot.hasError) {
              return Center(child: Text('Error: ${snapshot.error}'));
            }

            if (!snapshot.hasData || snapshot.data!.isEmpty) {
              return Center(child: Text('No attendance records available.'));
            }

            final records = snapshot.data!;

            return Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(
                    child: SingleChildScrollView(
                      scrollDirection: Axis.vertical,
                      child: SingleChildScrollView(
                        scrollDirection: Axis.horizontal,
                        child: DataTable(
                          headingRowColor: MaterialStateColor.resolveWith(
                              (states) => Color(0xff1b9bda)),
                          columnSpacing: 35.0,
                          columns: [
                            DataColumn(
                              label: Text(
                                'Date',
                                style: TextStyle(
                                    color: Colors.white, fontSize: 16),
                              ),
                            ),
                            DataColumn(
                              label: Text(
                                'Time',
                                style: TextStyle(
                                    color: Colors.white, fontSize: 16),
                              ),
                            ),
                            DataColumn(
                              label: Text(
                                'ID',
                                style: TextStyle(
                                    color: Colors.white, fontSize: 16),
                              ),
                            ),
                            DataColumn(
                              label: Text(
                                'Status',
                                style: TextStyle(
                                    color: Colors.white, fontSize: 16),
                              ),
                            ),
                          ],
                          rows: records.map((record) {
                            DateTime? timestamp = record['timestamp'];
                            String date = timestamp != null
                                ? '${timestamp.day}-${timestamp.month}-${timestamp.year}'
                                : 'N/A';
                            String time = timestamp != null
                                ? '${timestamp.hour}:${timestamp.minute}'
                                : 'N/A';

                            return DataRow(
                              cells: [
                                DataCell(Text(date)),
                                DataCell(Text(time)),
                                DataCell(Text(record['studentId'])),
                                DataCell(
                                  Text(
                                    record['status'],
                                    style: TextStyle(
                                      color: record['status'] == 'Present'
                                          ? Colors.green
                                          : Colors.red,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ),
                              ],
                              color: MaterialStateColor.resolveWith(
                                (states) => record['status'] == 'Present'
                                    ? Colors.green.shade50
                                    : Colors.red.shade50,
                              ),
                            );
                          }).toList(),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }
}
