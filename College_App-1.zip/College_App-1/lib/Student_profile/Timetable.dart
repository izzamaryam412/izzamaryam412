import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';

class Timetable extends StatefulWidget {
  final String department;

  Timetable({required this.department});

  @override
  _TimetableState createState() => _TimetableState();
}

class _TimetableState extends State<Timetable> {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  late Stream<Map<String, Map<String, List<Map<String, String>>>>> _timetableStream;
  Map<String, Map<String, List<Map<String, String>>>> localTimetable = {};

  @override
  void initState() {
    super.initState();
    _loadLocalTimetable(); // Load locally saved data
    _timetableStream = _getTimetableStream();
  }

  Future<void> _loadLocalTimetable() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? timetableJson = prefs.getString('timetable_${widget.department}');

    if (timetableJson != null) {
      setState(() {
        localTimetable =
        Map<String, Map<String, List<Map<String, String>>>>.from(json.decode(timetableJson));
      });
    }
  }

  Future<void> _saveTimetableToLocalStorage(
      Map<String, Map<String, List<Map<String, String>>>> timetable) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String timetableJson = json.encode(timetable);
    await prefs.setString('timetable_${widget.department}', timetableJson);
  }

  Stream<Map<String, Map<String, List<Map<String, String>>>>> _getTimetableStream() {
    return _firestore
        .collection('Timetable')
        .doc(widget.department)
        .collection('Days')
        .snapshots()
        .map((snapshot) {
      Map<String, Map<String, List<Map<String, String>>>> timetable = {};

      for (var dayDoc in snapshot.docs) {
        String day = dayDoc.id;
        Map<String, dynamic> subjectsData = dayDoc.data() as Map<String, dynamic>;

        List<Map<String, String>> subjects = [];
        if (subjectsData.containsKey('subjects')) {
          for (var subject in subjectsData['subjects']) {
            subjects.add(Map<String, String>.from(subject));
          }
        }

        timetable[day] = {
          'subjects': subjects,
        };
      }

      _saveTimetableToLocalStorage(timetable); // Save to local storage
      return timetable;
    });
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          title: Text('Timetable - ${widget.department} ',style: TextStyle(color: Colors.white),),
          backgroundColor: Color(0xff1b9bda),
          iconTheme: IconThemeData(
            color: Colors.white,
          ),
        ),
        body: Center(
          child: SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(height: 16),
                  // Space between department name and table
                  StreamBuilder<Map<String, Map<String, List<Map<String, String>>>>>(
                    stream: _timetableStream,
                    builder: (context, snapshot) {
                      if (snapshot.connectionState == ConnectionState.waiting &&
                          localTimetable.isEmpty) {
                        return Center(child: CircularProgressIndicator());
                      }

                      if (snapshot.hasError) {
                        return Center(child: Text('Error: ${snapshot.error}'));
                      }

                      final timetable = snapshot.hasData ? snapshot.data! : localTimetable;

                      if (timetable.isEmpty) {
                        return Center(child: Text('No timetable data available.'));
                      }

                      return Column(
                        children: timetable.keys.map((day) {
                          List<Map<String, String>> subjects = timetable[day]!['subjects'] ?? [];

                          return Padding(
                            padding: const EdgeInsets.symmetric(vertical: 8.0),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  day,
                                  style: TextStyle(
                                    fontSize: 18, // Day title font size
                                    fontWeight: FontWeight.bold,
                                    color: Color(0xff1b9bda), // Day title color
                                  ),
                                ),
                                SizedBox(height: 8),
                                // Space between day title and table
                                Table(
                                  border: TableBorder.all(
                                    color: Colors.blueGrey, // Line color
                                    width: 1, // Line width
                                  ),
                                  columnWidths: const <int, TableColumnWidth>{
                                    0: FlexColumnWidth(3),
                                    1: FlexColumnWidth(2),
                                  },
                                  children: [
                                    TableRow(
                                      decoration: BoxDecoration(
                                        color: Color(0xff1b9bda), // Dark blue for table header
                                      ),
                                      children: [
                                        Padding(
                                          padding: const EdgeInsets.all(8.0),
                                          child: Text(
                                            'Subject',
                                            style: TextStyle(
                                              fontSize: 16,
                                              fontWeight: FontWeight.bold,
                                              color: Colors.white,
                                            ),
                                          ),
                                        ),
                                        Padding(
                                          padding: const EdgeInsets.all(8.0),
                                          child: Text(
                                            'Time',
                                            style: TextStyle(
                                              fontSize: 16,
                                              fontWeight: FontWeight.bold,
                                              color: Colors.white,
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                    ...subjects.map((subject) {
                                      return TableRow(
                                        decoration: BoxDecoration(
                                          color: Colors.white, // Light pink for data rows
                                        ),
                                        children: [
                                          Padding(
                                            padding: const EdgeInsets.all(8.0),
                                            child: Text(
                                              subject['subject'] ?? 'N/A',
                                              style: TextStyle(
                                                fontSize: 14,
                                                color: Colors.blueGrey[800],
                                              ),
                                            ),
                                          ),
                                          Padding(
                                            padding: const EdgeInsets.all(8.0),
                                            child: Text(
                                              subject['time'] ?? 'N/A',
                                              style: TextStyle(
                                                fontSize: 14,
                                                color: Colors.blueGrey[800],
                                              ),
                                            ),
                                          ),
                                        ],
                                      );
                                    }).toList(),
                                  ],
                                ),
                              ],
                            ),
                          );
                        }).toList(),
                      );
                    },
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
