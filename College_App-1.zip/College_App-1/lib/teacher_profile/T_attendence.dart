import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:college_app/teacher_profile/AttendanceRecordsPage.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class AttendenceT extends StatefulWidget {
  final String department;
  final List<String> studentIds;

  AttendenceT({
    required this.department,
    required this.studentIds,
  });

  @override
  _AttendenceTState createState() => _AttendenceTState();
}

class _AttendenceTState extends State<AttendenceT> {
  List<String> present = [];
  List<String> absent = [];

  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  Future<void> _saveAttendance() async {
    try {
      String attendanceId = DateTime.now().toIso8601String();

      for (String studentId in present) {
        await _firestore
            .collection('attendance')
            .doc(widget.department)
            .collection(studentId)
            .doc(attendanceId)
            .set({
          'ID': attendanceId,
          'status': 'Present',
          'timestamp': FieldValue.serverTimestamp(),
          'studentId': studentId, // Save studentId
        });
      }

      for (String studentId in absent) {
        await _firestore
            .collection('attendance')
            .doc(widget.department)
            .collection(studentId)
            .doc(attendanceId)
            .set({
          'ID': studentId,
          'status': 'Absent',
          'timestamp': FieldValue.serverTimestamp(),
          'studentId': studentId, // Save studentId
        });
      }

      for (String studentId in present) {
        await _notifyStudent(studentId, 'Present');
      }

      for (String studentId in absent) {
        await _notifyStudent(studentId, 'Absent');
      }

      ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Attendance saved successfully!')));
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to save attendance: $e')));
    }
  }

  Future<void> _notifyStudent(String studentId, String status) async {
    try {
      DocumentSnapshot studentDoc =
          await _firestore.collection('students').doc(studentId).get();

      if (studentDoc.exists) {
        String? fcmToken = studentDoc.get('fcmToken');
        if (fcmToken != null) {
          await _sendNotification(
              fcmToken, 'Attendance Status', 'You have been marked $status.');
        }
      }
    } catch (e) {
      print('Failed to send notification: $e');
    }
  }

  Future<void> _sendNotification(
      String fcmToken, String title, String body) async {
    try {
      final String serverKey =
          'YOUR_SERVER_KEY'; // Replace with your FCM server key
      final Uri url = Uri.parse('https://fcm.googleapis.com/fcm/send');

      final Map<String, dynamic> notification = {
        'notification': {
          'title': title,
          'body': body,
        },
        'priority': 'high',
        'to': fcmToken,
      };

      final http.Response response = await http.post(
        url,
        headers: <String, String>{
          'Content-Type': 'application/json',
          'Authorization': 'key=$serverKey',
        },
        body: jsonEncode(notification),
      );

      if (response.statusCode == 200) {
        print('Notification sent successfully');
      } else {
        print(
            'Failed to send notification. Status code: ${response.statusCode}');
      }
    } catch (e) {
      print('Error sending notification: $e');
    }
  }

  Future<List<Map<String, dynamic>>> _fetchAttendanceRecords() async {
    try {
      List<Map<String, dynamic>> records = [];

      // Fetch all student documents from the attendance collection for the department
      for (String studentId in widget.studentIds) {
        QuerySnapshot attendanceSnapshot = await _firestore
            .collection('attendance')
            .doc(widget.department)
            .collection(studentId)
            .get();

        for (DocumentSnapshot record in attendanceSnapshot.docs) {
          records.add({
            'ID': record['ID'],
            'status': record['status'],
            'studentId': record['studentId'],
            'timestamp': record['timestamp']?.toDate(),
          });
        }
      }

      return records;
    } catch (e) {
      print('Error fetching records: $e');
      return [];
    }
  }

  void _showAttendanceRecords() async {
    List<Map<String, dynamic>> records = await _fetchAttendanceRecords();

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => AttendanceRecordsPage(
          records: records,
          department: widget.department,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: Color.fromARGB(255, 101, 8, 117),
          title: Text('${widget.department} Details',style: TextStyle(color: Colors.white),),
          iconTheme: IconThemeData(
            color: Colors.white,
          ),
        ),
        body: Column(
          children: [
            Expanded(
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(height: 20),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          'Present: ${present.length}',
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.w600,
                            color: Colors.green,
                          ),
                        ),
                        Text(
                          'Absent: ${absent.length}',
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.w600,
                            color: Colors.red,
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: 20),
                    Expanded(
                      child: ListView.builder(
                        itemCount: widget.studentIds.length,
                        itemBuilder: (context, index) {
                          String studentId = widget.studentIds[index];
                          return Card(
                            color: Color.fromARGB(255, 101, 8, 117).withOpacity(0.7),
                            elevation: 5,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(15),
                            ),
                            child: ListTile(
                              title: Text(
                                studentId,
                                style: TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.w600,
                                  color: Colors.white,
                                ),
                              ),
                              trailing: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  ElevatedButton(
                                    onPressed: () {
                                      setState(() {
                                        if (absent.contains(studentId)) {
                                          absent.remove(studentId);
                                        }
                                        if (!present.contains(studentId)) {
                                          present.add(studentId);
                                        }
                                      });
                                    },
                                    style: ElevatedButton.styleFrom(
                                      backgroundColor: present.contains(studentId)
                                          ? Color.fromARGB(255, 0, 228, 8)
                                          : const Color.fromARGB(
                                              255, 210, 211, 210),
                                    ),
                                    child: Text(
                                      'Present',
                                      style: TextStyle(
                                        color: present.contains(studentId)
                                            ? Colors.white
                                            : Colors.black,
                                      ),
                                    ),
                                  ),
                                  SizedBox(width: 10),
                                  ElevatedButton(
                                    onPressed: () {
                                      setState(() {
                                        if (present.contains(studentId)) {
                                          present.remove(studentId);
                                        }
                                        if (!absent.contains(studentId)) {
                                          absent.add(studentId);
                                        }
                                      });
                                    },
                                    style: ElevatedButton.styleFrom(
                                      backgroundColor: absent.contains(studentId)
                                          ? Color.fromARGB(255, 248, 20, 4)
                                          : const Color.fromARGB(
                                              255, 236, 234, 234),
                                    ),
                                    child: Text(
                                      'Absent',
                                      style: TextStyle(
                                        color: absent.contains(studentId)
                                            ? Colors.white
                                            : Colors.black,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          );
                        },
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Container(
              padding: EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: Color.fromARGB(255, 101, 8, 117),
                borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  ElevatedButton(
                    onPressed: _saveAttendance,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.green,
                      padding: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                    ),
                    child: Text(
                      'Save Attendance',
                      style: TextStyle(color: Colors.white),
                    ),
                  ),
                  ElevatedButton(
                    onPressed: _showAttendanceRecords,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.white,
                      padding: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                    ),
                    child: Text(
                      'View Records',
                      style: TextStyle(color:Color.fromARGB(255, 101, 8, 117)),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
