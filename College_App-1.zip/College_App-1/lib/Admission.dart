import 'dart:io';
import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:image_picker/image_picker.dart';
import 'package:open_file/open_file.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'Submit.dart'; // Ensure this import is correct

class Admission extends StatefulWidget {
  @override
  _AdmissionState createState() => _AdmissionState();
}

class _AdmissionState extends State<Admission> {
  final _formKey = GlobalKey<FormState>();
  final _dobController = TextEditingController();
  final _firstNameController = TextEditingController();
  final _lastNameController = TextEditingController();
  final _fatherNameController = TextEditingController();
  final _emailController = TextEditingController();
  final _phoneNumberController = TextEditingController();
  final _addressController = TextEditingController();
  File? _selectedPicture;
  List<File> _selectedDocuments = [];
  String? _selectedGender;
  String? _selectedCourse;

  @override
  Future<void> _pickImage() async {
    final pickedFile =
    await ImagePicker().pickImage(source: ImageSource.gallery);
    if (pickedFile != null) {
      setState(() {
        _selectedPicture = File(pickedFile.path);
      });
    }
  }

  Future<void> _pickDocuments() async {
    FilePickerResult? result =
    await FilePicker.platform.pickFiles(allowMultiple: true);
    if (result != null) {
      setState(() {
        _selectedDocuments = result.paths.map((path) => File(path!)).toList();
      });
    }
  }

  void _removePicture() {
    setState(() {
      _selectedPicture = null;
    });
  }

  void _removeDocument(int index) {
    setState(() {
      _selectedDocuments.removeAt(index);
    });
  }

  Future<String?> uploadImage(File image) async {
    try {
      final storageRef = FirebaseStorage.instance.ref().child(
          'images/${DateTime.now().toIso8601String()}_${image.uri.pathSegments.last}');
      await storageRef.putFile(image);
      return await storageRef.getDownloadURL();
    } catch (e) {
      print("Error uploading image: $e");
      return null;
    }
  }

  Future<String?> uploadPdf(File pdf) async {
    try {
      final storageRef = FirebaseStorage.instance.ref().child(
          'pdfs/${DateTime.now().toIso8601String()}_${pdf.uri.pathSegments.last}');
      await storageRef.putFile(pdf);
      return await storageRef.getDownloadURL();
    } catch (e) {
      print("Error uploading PDF: $e");
      return null;
    }
  }

  Future<void> _submitForm() async {
    if (_formKey.currentState!.validate()) {
      String firstName = _firstNameController.text;
      String lastName = _lastNameController.text;
      String fatherName = _fatherNameController.text;
      String email = _emailController.text;
      String phoneNumber = _phoneNumberController.text;
      String address = _addressController.text;
      String dob = _dobController.text;
      String gender = _selectedGender ?? '';
      String course = _selectedCourse ?? '';

      // Upload picture if selected
      String? pictureUrl;
      if (_selectedPicture != null) {
        pictureUrl = await uploadImage(_selectedPicture!);
      }

      // Upload documents if selected
      List<String> documentUrls = [];
      for (File doc in _selectedDocuments) {
        String? docUrl = await uploadPdf(doc);
        if (docUrl != null) {
          documentUrls.add(docUrl);
        }
      }

      // Prepare data for Firestore
      FirebaseFirestore firestore = FirebaseFirestore.instance;
      CollectionReference admissions = firestore.collection('admissions');

      // Add the data to Firestore
      await admissions
          .add({
        'firstName': firstName,
        'lastName': lastName,
        'fatherName': fatherName,
        'email': email,
        'phoneNumber': phoneNumber,
        'address': address,
        'dob': dob,
        'gender': gender,
        'course': course,
        'pictureUrl': pictureUrl,
        'documents': documentUrls,
      })
          .then((value) => print('Data added to Firestore successfully'))
          .catchError(
              (error) => print('Failed to add data to Firestore: $error'));

      // Navigate to the Submit screen
      Navigator.push(
        context,
        MaterialPageRoute(builder: (context) => Submit()),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: Stack(
          children: [
            Container(
              width: double.infinity,
              height: double.infinity,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    Color(0xff1b9bda),
                    Color.fromARGB(255, 101, 8, 117),// Second color
                  ],
                  begin: Alignment.topLeft,           // Start position of the gradient
                  end: Alignment.topRight,         // End position of the gradient
                ),
              ),
            ),
            Center(
              child: SingleChildScrollView(
                child: Padding(
                  padding: const EdgeInsets.only(top:45.0,right: 16,left: 16,bottom: 16),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(15),
                    child: Container(
                      width: double.infinity,
                      color: Colors.white.withOpacity(0.7),
                      padding: EdgeInsets.all(16.0),
                      child: Form(
                        key: _formKey,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Admission Form',
                              style: TextStyle(
                                fontSize: 24,
                                fontWeight: FontWeight.bold,
                                color: Color(0xff1b9bda),
                              ),
                            ),
                            SizedBox(height: 20),
                            buildTextField('First name *',
                                controller: _firstNameController),
                            buildTextField('Last name *',
                                controller: _lastNameController),
                            buildTextField('Father name *',
                                controller: _fatherNameController),
                            buildEmailField(),
                            buildTextField('Phone Number *',
                                keyboardType: TextInputType.phone,
                                controller: _phoneNumberController),
                            buildTextField('Address *',
                                controller: _addressController),
                            buildDateField(context),
                            buildDropdownField(
                                'Gender *', ['Male', 'Female', 'Other'],
                                    (value) {
                                  setState(() {
                                    _selectedGender = value;
                                  });
                                }, _selectedGender),
                            buildDropdownField('Course *', [
                              'BS Infomation Technology',
                              'BS Economics',
                              'BS Islamiyat'
                            ], (value) {
                              setState(() {
                                _selectedCourse = value;
                              });
                            }, _selectedCourse),
                            SizedBox(height: 10),
                            Text(
                              'Upload Picture',
                              style: TextStyle(
                                  color: Color(0xff1b9bda),
                                  fontWeight: FontWeight.bold),
                            ),
                            SizedBox(height: 10),
                            Container(
                              decoration: BoxDecoration(
                                gradient: LinearGradient(
                                  colors: [
                                    Color.fromARGB(255, 101, 8, 117),// Second color
                                    Color(0xff1b9bda),
                                  ],
                                  begin: Alignment.topLeft,           // Start position of the gradient
                                  end: Alignment.topRight,         // End position of the gradient
                                ),
                                borderRadius: BorderRadius.circular(30.0),  // to match button shape
                              ),
                              child: ElevatedButton(
                                onPressed: _pickImage,
                                child: Text('Select Picture',
                                    style: TextStyle(color: Colors.white)),
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: Colors.transparent,  // make button background transparent
                                  shadowColor: Colors.transparent,  // remove shadow
                                ),
                              ),
                            ),
                            _selectedPicture != null
                                ? Column(
                              children: [
                                Image.file(_selectedPicture!,
                                    height: 100, width: 100),
                                IconButton(
                                  icon: Icon(Icons.delete,
                                      color: Colors.red),
                                  onPressed: _removePicture,
                                ),
                              ],
                            )
                                : Container(),
                            SizedBox(height: 20),
                            Text(
                              'Upload Documents',
                              style: TextStyle(
                                  color: Color(0xff1b9bda),
                                  fontWeight: FontWeight.bold),
                            ),
                            SizedBox(height: 10),
                            Container(
                              decoration: BoxDecoration(
                                gradient: LinearGradient(
                                  colors: [
                                    Color.fromARGB(255, 101, 8, 117),// Second color
                                    Color(0xff1b9bda),
                                  ],
                                  begin: Alignment.topLeft,           // Start position of the gradient
                                  end: Alignment.topRight,         // End position of the gradient
                                ),
                                borderRadius: BorderRadius.circular(30.0),  // to match button shape
                              ),
                              child: ElevatedButton(
                                onPressed: _pickDocuments,
                                child: Text('Select Documents',
                                    style: TextStyle(color: Colors.white)),
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: Colors.transparent,  // make button background transparent
                                  shadowColor: Colors.transparent,  // remove shadow
                                ),
                              ),
                            ),
                            _selectedDocuments.isNotEmpty
                                ? Column(
                              children: _selectedDocuments.map((file) {
                                int index =
                                _selectedDocuments.indexOf(file);
                                return ListTile(
                                  leading: Icon(
                                    Icons.insert_drive_file,
                                    color: Color(0xff1b9bda),
                                  ),
                                  title: Text(file.path.split('/').last,
                                      style: TextStyle(
                                          color: Color(0xff1b9bda))),
                                  trailing: IconButton(
                                    icon: Icon(Icons.delete,
                                        color: Colors.red),
                                    onPressed: () =>
                                        _removeDocument(index),
                                  ),
                                  onTap: () => OpenFile.open(file.path),
                                );
                              }).toList(),
                            )
                                : Container(),
                            SizedBox(height: 20),
                            Center(
                              child: Container(
                                decoration: BoxDecoration(
                                  gradient: LinearGradient(
                                    colors: [
                                      Color.fromARGB(255, 101, 8, 117),// Second color
                                      Color(0xff1b9bda),
                                    ],
                                    begin: Alignment.topLeft,           // Start position of the gradient
                                    end: Alignment.topRight,         // End position of the gradient
                                  ),
                                  borderRadius: BorderRadius.circular(30.0),  // to match button shape
                                ),
                                child: ElevatedButton(
                                  onPressed: _submitForm,
                                  child: Text('Submit',style: TextStyle(color: Colors.white,),),
                                  style: ElevatedButton.styleFrom(
                                      backgroundColor: Colors.transparent,
                                      shadowColor: Colors.transparent,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget buildTextField(String label,
      {TextEditingController? controller, TextInputType? keyboardType}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16.0),
      child: TextFormField(
        controller: controller,
        style: TextStyle(
          color: Color(0xff1b9bda), // Text color when typing
        ),
        keyboardType: keyboardType,
        decoration: InputDecoration(
          labelText: label,
          labelStyle: TextStyle(color: Color(0xff1b9bda)),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide: BorderSide(color: Color(0xff1b9bda)),
          ),
        ),
        validator: (value) {
          if (value == null || value.isEmpty) {
            return 'Please enter $label';
          }
          return null;
        },
      ),
    );
  }

  Widget buildEmailField() {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16.0),
      child: TextFormField(
        controller: _emailController,
        keyboardType: TextInputType.emailAddress,
        style: TextStyle(
          color: Color(0xff1b9bda), // Text color when typing
        ),
        decoration: InputDecoration(
          labelText: 'Email *',
          labelStyle: TextStyle(color: Color(0xff1b9bda)),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide: BorderSide(color: Color(0xff1b9bda)),
          ),
        ),
        validator: (value) {
          if (value == null || value.isEmpty) {
            return 'Please enter your email';
          } else if (!RegExp(r'^[^@]+@[^@]+\.[^@]+').hasMatch(value)) {
            return 'Please enter a valid email address';
          }
          return null;
        },
      ),
    );
  }

  Widget buildDateField(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16.0),
      child: TextFormField(
        controller: _dobController,
        style: TextStyle(
          color: Color(0xff1b9bda), // Text color when typing
        ),
        decoration: InputDecoration(
          labelText: 'Date of Birth *',
          labelStyle: TextStyle(color: Color(0xff1b9bda)),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide: BorderSide(color: Color(0xff1b9bda)),
          ),
        ),
        readOnly: true,
        onTap: () async {
          DateTime? pickedDate = await showDatePicker(
            context: context,
            initialDate: DateTime.now(),
            firstDate: DateTime(1900),
            lastDate: DateTime.now(),
          );
          if (pickedDate != null) {
            setState(() {
              _dobController.text = '${pickedDate.toLocal()}'.split(' ')[0];
            });
          }
        },
        validator: (value) {
          if (value == null || value.isEmpty) {
            return 'Please enter your date of birth';
          }
          return null;
        },
      ),
    );
  }

  Widget buildDropdownField(String label, List<String> items,
      ValueChanged<String?> onChanged, String? selectedItem) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16.0),
      child: DropdownButtonFormField<String>(
        value: selectedItem,
        iconEnabledColor: Color(0xff1b9bda),
        style: TextStyle(
          color: Color(0xff1b9bda), // Text color when typing
        ),
        decoration: InputDecoration(
          labelText: label,
          labelStyle: TextStyle(color: Color(0xff1b9bda)),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide: BorderSide(color: Color(0xff1b9bda)),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide: BorderSide(color: Color(0xff1b9bda)),
          ),
        ),
        items: items.map((item) {
          return DropdownMenuItem<String>(
            value: item,
            child: Text(item),
          );
        }).toList(),
        onChanged: onChanged,
        validator: (value) {
          if (value == null) {
            return 'Please select $label';
          }
          return null;
        },
      ),
    );
  }
}
