import 'package:flutter/material.dart';

class AttendanceRecordsPage extends StatelessWidget {
  final List<Map<String, dynamic>> records;
  final String department;

  AttendanceRecordsPage({
    required this.records,
    required this.department,
  }) {
    // Sort the records by date (latest first), and then by status ("Present" before "Absent")
    records.sort((a, b) {
      DateTime dateA = a['timestamp'] ?? DateTime.now();
      DateTime dateB = b['timestamp'] ?? DateTime.now();

      // First, compare dates in descending order
      int dateComparison = dateB.compareTo(dateA);
      if (dateComparison != 0) return dateComparison;

      // If dates are the same, compare status (Present first)
      String statusA = a['status'] ?? '';
      String statusB = b['status'] ?? '';

      if (statusA == statusB) return 0;
      if (statusA == 'Present') return -1;
      if (statusB == 'Present') return 1;
      return 0;
    });
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          title: Text('$department Attendance Records',style: TextStyle(color: Colors.white),),
          backgroundColor: Color.fromARGB(255, 101, 8, 117),
          iconTheme: IconThemeData(
            color: Colors.white,
          ),
        ),
        body: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Department: $department',
                style: TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                  color: Color.fromARGB(255, 101, 8, 117),
                ),
              ),
              SizedBox(height: 20),
              Expanded(
                child: SingleChildScrollView(
                  scrollDirection: Axis.vertical,
                  child: SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: DataTable(
                      headingRowColor: MaterialStateColor.resolveWith(
                          (states) => Color.fromARGB(255, 101, 8, 117)),
                      columnSpacing: 35.0,
                      columns: [
                        DataColumn(
                          label: Text(
                            'Date',
                            style: TextStyle(color: Colors.white, fontSize: 16),
                          ),
                        ),
                        DataColumn(
                          label: Text(
                            'Time',
                            style: TextStyle(color: Colors.white, fontSize: 16),
                          ),
                        ),
                        DataColumn(
                          label: Text(
                            'ID',
                            style: TextStyle(color: Colors.white, fontSize: 16),
                          ),
                        ),
                        DataColumn(
                          label: Text(
                            'Status',
                            style: TextStyle(color: Colors.white, fontSize: 16),
                          ),
                        ),
                      ],
                      rows: records.map((record) {
                        DateTime? timestamp = record['timestamp'];
                        String date = timestamp != null
                            ? '${timestamp.day}-${timestamp.month}-${timestamp.year}'
                            : 'N/A';
                        String time = timestamp != null
                            ? '${timestamp.hour}:${timestamp.minute}'
                            : 'N/A';

                        return DataRow(
                          cells: [
                            DataCell(Text(date)),
                            DataCell(Text(time)),
                            DataCell(Text(record['studentId'])),
                            DataCell(
                              Text(
                                record['status'],
                                style: TextStyle(
                                  color: record['status'] == 'Present'
                                      ? Colors.green
                                      : Colors.red,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          ],
                          color: MaterialStateColor.resolveWith(
                            (states) => record['status'] == 'Present'
                                ? Colors.green.shade50
                                : Colors.red.shade50,
                          ),
                        );
                      }).toList(),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
