
import 'package:curved_navigation_bar/curved_navigation_bar.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:vibration/vibration.dart';
import 'package:overlay_support/overlay_support.dart';
import 'package:just_audio/just_audio.dart';
import 'package:flutter_app_badger/flutter_app_badger.dart';
import 'dart:async';

class TNotification extends StatefulWidget {
  @override
  _TNotificationState createState() => _TNotificationState();
}

class _TNotificationState extends State<TNotification>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<Offset> _animation1;
  late Animation<Offset> _animation2;
  late Animation<Offset> _animation3;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: Duration(milliseconds: 800),
      vsync: this,
    );

    _animation1 = Tween<Offset>(
      begin: Offset(-1.5, 0.0),
      end: Offset(0.0, 0.0),
    ).animate(
      CurvedAnimation(
        parent: _controller,
        curve: Curves.easeInOut,
      ),
    );

    _animation2 = Tween<Offset>(
      begin: Offset(-1.5, 0.0),
      end: Offset(0.0, 0.0),
    ).animate(
      CurvedAnimation(
        parent: _controller,
        curve: Interval(
          0.2, 1.0,
          curve: Curves.easeInOut,
        ),
      ),
    );

    _animation3 = Tween<Offset>(
      begin: Offset(-1.5, 0.0),
      end: Offset(0.0, 0.0),
    ).animate(
      CurvedAnimation(
        parent: _controller,
        curve: Interval(
          0.4, 1.0,
          curve: Curves.easeInOut,
        ),
      ),
    );

    _controller.forward();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }


  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: Color.fromARGB(255, 101, 8, 117),
          title: Center(child: Text('Select Department',style: TextStyle(color: Colors.white,fontWeight: FontWeight.bold),)),
          automaticallyImplyLeading: false,
        ),
        body: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            AnimatedBuilder(
              animation: _controller,
              builder: (context, child) {
                return SlideTransition(
                  position: _animation1,
                  child: DepartmentContainer(
                    departmentName: 'Economics',
                    color:Color.fromARGB(255, 101, 8, 117),
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => NotificationsT(department: 'Economic'),
                        ),
                      );
                    },
                  ),
                );
              },
            ),
            AnimatedBuilder(
              animation: _controller,
              builder: (context, child) {
                return SlideTransition(
                  position: _animation2,
                  child: DepartmentContainer(
                    departmentName: 'IT',
                    color: Color.fromARGB(255, 101, 8, 117),
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => NotificationsT(department: 'IT'),
                        ),
                      );
                    },
                  ),
                );
              },
            ),
            AnimatedBuilder(
              animation: _controller,
              builder: (context, child) {
                return SlideTransition(
                  position: _animation3,
                  child: DepartmentContainer(
                    departmentName: 'Islamiat',
                    color:Color.fromARGB(255, 101, 8, 117),
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => NotificationsT(department: 'Islamiat'),
                        ),
                      );
                    },
                  ),
                );
              },
            ),
          ],
        ),
        bottomNavigationBar: CurvedNavigationBar(
          color:  Color.fromARGB(255, 101, 8, 117),
          backgroundColor: Colors.transparent,
          buttonBackgroundColor:  Color.fromARGB(255, 101, 8, 117),
          animationCurve: Curves.easeInOut,
          animationDuration: Duration(milliseconds: 600),
          items: <Widget>[
            Icon(Icons.home, size: 30, color: Colors.white),
            Icon(Icons.group, size: 30, color: Colors.white),
            Icon(Icons.notifications, size: 30, color: Colors.white),
          ],
        ),
      ),
    );
  }
}


class DepartmentContainer extends StatelessWidget {
  final String departmentName;
  final Color color;
  final VoidCallback onTap;

  DepartmentContainer({
    required this.departmentName,
    required this.color,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: EdgeInsets.symmetric(vertical: 8.0, horizontal: 16.0),
        padding: EdgeInsets.all(32.0),
        decoration: BoxDecoration(
          color: color,
          borderRadius: BorderRadius.circular(12.0),
          boxShadow: [
            BoxShadow(
              color: Colors.black26,
              blurRadius: 4.0,
              offset: Offset(2, 2),
            ),
          ],
        ),
        child: Center(
          child: Text(
            departmentName,
            style: TextStyle(
              color: Colors.white,
              fontSize: 24.0,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
      ),
    );

  }
}

class NotificationsT extends StatefulWidget {
  final String department;

  NotificationsT({required this.department});

  @override
  _NotificationsTState createState() => _NotificationsTState();
}

class _NotificationsTState extends State<NotificationsT> {
  final AudioPlayer player = AudioPlayer();
  int notificationCount = 0;
  late StreamSubscription<QuerySnapshot> _notificationSubscription;
  List<Map<String, dynamic>> _notifications = [];

  @override
  void initState() {
    super.initState();
    _initializeNotifications();
  }

  Future<void> _playNotificationSound() async {
    await player.setAsset('assets/simple-notification-152054.mp3');
    player.play();
  }

  void _initializeNotifications() {
    FirebaseFirestore firestore = FirebaseFirestore.instance;
    CollectionReference ref = firestore
        .collection('T_notifications')
        .doc(widget.department)
        .collection('T_notifications');

    _notificationSubscription = ref.snapshots().listen((QuerySnapshot snapshot) {
      if (snapshot.docs.isNotEmpty) {
        Vibration.vibrate();
        _playNotificationSound();

        setState(() {
          _notifications.clear();
          snapshot.docs.forEach((doc) {
            _notifications.add({
              'message': doc['message'],
              'timestamp': doc['timestamp'].toDate().toString(),
            });
          });
          notificationCount = _notifications.length;
          FlutterAppBadger.updateBadgeCount(notificationCount);
        });

        if (_notifications.isNotEmpty) {
          final notificationData = _notifications.last;
          showSimpleNotification(
            Text('New Notification'),
            subtitle: Text(notificationData['message']),
            background: Colors.green,
          );
        }
      } else {
        setState(() {
          _notifications.clear();
          notificationCount = 0;
          FlutterAppBadger.updateBadgeCount(notificationCount);
        });
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: Color.fromARGB(255, 101, 8, 117),
          title: Text(
            'Notifications - ${widget.department}',
            style: TextStyle(color: Colors.white),
          ),
           automaticallyImplyLeading: false,
          actions: [
            if (notificationCount > 0)
              Padding(
                padding:  const EdgeInsets.only(right: 8),
                child: Stack(
                  children: [
                    Icon(Icons.notifications,color: Colors.white,size: 30,),
                    Positioned(
                      right: 0,
                      child: Container(
                        padding: EdgeInsets.all(1),
                        decoration: BoxDecoration(
                          color: Colors.red,
                          borderRadius: BorderRadius.circular(6),
                        ),
                        constraints: BoxConstraints(
                          minWidth: 12,
                          minHeight: 12,
                        ),
                        child: Text(
                          '$notificationCount',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 8,
                            fontWeight: FontWeight.bold,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
          ],
        ),
        body: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(height: 16), // Space between department name and notifications
              Expanded(
                child: _notifications.isEmpty
                    ? Center(
                  child: Text(
                    'No notifications available for ${widget.department}.',
                    style: TextStyle(fontSize: 16),
                  ),
                )
                    : ListView.builder(
                  itemCount: _notifications.length,
                  itemBuilder: (context, index) {
                    final notification = _notifications[index];
                    return Container(
                      margin: EdgeInsets.symmetric(vertical: 8.0, horizontal: 16.0),
                      padding: EdgeInsets.all(16.0),
                      decoration: BoxDecoration(
                        color: Color.fromARGB(255, 101, 8, 117),
                        borderRadius: BorderRadius.circular(12.0),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black26,
                            blurRadius: 4.0,
                            offset: Offset(2, 2),
                          ),
                        ],
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            notification['message'],
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 16.0,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          SizedBox(height: 8.0),
                          Text(
                            notification['timestamp'] ?? 'No timestamp available',
                            style: TextStyle(
                              color: Colors.white70,
                              fontSize: 14.0,
                            ),
                          ),
                        ],
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        ),

      ),
    );
  }

  @override
  void dispose() {
    _notificationSubscription.cancel();
    player.dispose();
    super.dispose();
  }
}

void main() {
  runApp(
    OverlaySupport.global(
      child: MaterialApp(
        home: NotificationsT(department: 'Economics'), // Example department
        debugShowCheckedModeBanner: false,
      ),
    ),
  );
}
