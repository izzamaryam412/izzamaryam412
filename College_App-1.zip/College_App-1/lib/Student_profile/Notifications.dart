import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:vibration/vibration.dart';
import 'package:overlay_support/overlay_support.dart';
import 'package:just_audio/just_audio.dart';
import 'package:flutter_app_badger/flutter_app_badger.dart';
import 'dart:async';

class NotificationPage extends StatefulWidget {
  final String department;

  NotificationPage({required this.department});

  @override
  _NotificationPageState createState() => _NotificationPageState();
}

class _NotificationPageState extends State<NotificationPage> {
  final AudioPlayer player = AudioPlayer();
  int notificationCount = 0;
  late StreamSubscription<QuerySnapshot> _notificationSubscription;
  List<Map<String, dynamic>> _notifications = []; // To store notifications locally

  @override
  void initState() {
    super.initState();
    _initializeNotifications();
  }

  Future<void> _playNotificationSound() async {
    await player.setAsset('assets/simple-notification-152054.mp3');
    player.play();
  }

  void _initializeNotifications() {
    FirebaseFirestore firestore = FirebaseFirestore.instance;
    CollectionReference ref = firestore
        .collection('notifications')
        .doc(widget.department) // Use the department passed from the previous page
        .collection('notifications');

    _notificationSubscription = ref.snapshots().listen((QuerySnapshot snapshot) {
      if (snapshot.docs.isNotEmpty) {
        // Process new notifications
        Vibration.vibrate();
        _playNotificationSound();

        setState(() {
          // Clear the old notifications list and store the latest data
          _notifications.clear();
          snapshot.docs.forEach((doc) {
            _notifications.add({
              'message': doc['message'],
              'timestamp': doc['timestamp'].toDate().toString(),
            });
          });
          notificationCount = _notifications.length;
          FlutterAppBadger.updateBadgeCount(notificationCount);
        });

        if (_notifications.isNotEmpty) {
          final notificationData = _notifications.last;
          showSimpleNotification(
            Text('New Notification'),
            subtitle: Text(notificationData['message']),
            background: Colors.green,
          );
        }
      } else {
        // Handle case when no notifications are available
        setState(() {
          _notifications.clear();
          notificationCount = 0;
          FlutterAppBadger.updateBadgeCount(notificationCount);
        });
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: Color(0xff1b9bda),
          automaticallyImplyLeading: false,
          title: Text('Notifications - ${widget.department}',style: TextStyle(color:Colors.white,fontWeight: FontWeight.bold),),
          actions: [
            if (notificationCount > 0)
              Padding(
                padding: const EdgeInsets.only(right: 8),
                child: Stack(
                  children: [
                    Icon(Icons.notifications,color: Colors.white,size: 30,),
                    Positioned(
                      right: 0,
                      child: Container(
                        padding: EdgeInsets.all(1),
                        decoration: BoxDecoration(
                          color: Colors.red,
                          borderRadius: BorderRadius.circular(6),
                        ),
                        constraints: BoxConstraints(
                          minWidth: 12,
                          minHeight: 12,
                        ),
                        child: Text(
                          '$notificationCount',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 8,
                            fontWeight: FontWeight.bold,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ),
                    )
                  ],
                ),
              ),
          ],
        ),
        body:  SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(height: 16), // Space between department name and notifications
      
                  _notifications.isEmpty
                      ? Center(
                      child: Text('No notifications available for ${widget.department}.'))
                      : ListView.builder(
                    shrinkWrap: true,  // Prevents infinite height error
                    physics: NeverScrollableScrollPhysics(), // Disable scrolling for the inner ListView
                    itemCount: _notifications.length,
                    itemBuilder: (context, index) {
                      final notification = _notifications[index];
                      return Container(
                        margin: EdgeInsets.symmetric(vertical: 8.0, horizontal: 16.0),
                        padding: EdgeInsets.all(16.0),
                        decoration: BoxDecoration(
                          color:Color(0xff1b9bda),
                          borderRadius: BorderRadius.circular(12.0),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black26,
                              blurRadius: 4.0,
                              offset: Offset(2, 2),
                            ),
                          ],
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              notification['message'],
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 16.0,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            SizedBox(height: 8.0),
                            Text(
                              notification['timestamp'] ?? 'No timestamp available',
                              style: TextStyle(
                                color: Colors.white70,
                                fontSize: 14.0,
                              ),
                            ),
                          ],
                        ),
                      );
                    },
                  ),
                ],
              ),
            ),
          ),
      ),
    );
  }

  @override
  void dispose() {
    _notificationSubscription.cancel();
    player.dispose();
    super.dispose();
  }
}
