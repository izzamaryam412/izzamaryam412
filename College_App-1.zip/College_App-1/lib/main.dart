import 'dart:async';
import 'package:college_app/Loginpage.dart';
import 'package:college_app/firebase_options.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:overlay_support/overlay_support.dart'; // Import OverlaySupport
import 'package:hive_flutter/hive_flutter.dart';

import 'Admission.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );

  // Initialize Hive
  await Hive.initFlutter();

  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return OverlaySupport.global(
      // Wrap your app with OverlaySupport.global
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'College App',
        home: MyHomePage(),
      ),
    );
  }
}

class MyHomePage extends StatefulWidget {
  @override
  State<MyHomePage> createState() => MyHomePageState();
}

class MyHomePageState extends State<MyHomePage> {
  @override
  void initState() {
    super.initState();
    Timer(Duration(seconds: 4), () {
      Navigator.pushReplacement(
          context, MaterialPageRoute(builder: (context) => Admission()));
    });
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: Stack(
          children: [
            Container(
              height: double.infinity,
              width: double.infinity,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Center(
                    child: Text(
                      'College Link',
                      style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 35,
                          color: Colors.white),
                    ),
                  ),
                  Text(
                    'Spark your',
                    style: TextStyle(fontSize: 25, color: Colors.white),
                  ),
                  Text(
                    'Learning journey',
                    style: TextStyle(fontSize: 25, color: Colors.white),
                  ),
                ],
              ),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    Color(0xff1b9bda),
                    Color.fromARGB(255, 101, 8, 117),// Second color
                  ],
                  begin: Alignment.topLeft,           // Start position of the gradient
                  end: Alignment.topRight,         // End position of the gradient
                ),
              ),
            ),
           /*Positioned(
              right: 0,
              top: 360,
              child: Container(
                height: 140,
                width: 140,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(900),
                  gradient: LinearGradient(
                    colors: [
                      Color(0xff1b9bda),
                      Color.fromARGB(255, 101, 8, 117),// Second color
                    ],
                    begin: Alignment.topLeft,           // Start position of the gradient
                    end: Alignment.topRight,         // End position of the gradient
                  ),
                ),
              ),
            ),*/
          ],
        ),
      ),
    );
  }
}