import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:college_app/teacher_profile/VideoPlayerScreen.dart';
import 'package:file_picker/file_picker.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import 'package:url_launcher/url_launcher.dart'; // For handling URLs

class GroupChatScreen extends StatefulWidget {
  final String departmentName;
  final String name;
  final String id;

  const GroupChatScreen({
    required this.departmentName,
    required this.name,
    required this.id,
  });

  @override
  _GroupChatScreenState createState() => _GroupChatScreenState();
}

class _GroupChatScreenState extends State<GroupChatScreen> {
  final _messageController = TextEditingController();
  final _firestore = FirebaseFirestore.instance;
  final _storage = FirebaseStorage.instance;
  final _picker = ImagePicker();
  late String _chatRoomId;
  late Future<List<Map<String, dynamic>>> _memberDetails;

  @override
  void initState() {
    super.initState();
    _chatRoomId = widget.departmentName;
    _memberDetails = _fetchMemberDetails();
  }

  Future<List<Map<String, dynamic>>> _fetchMemberDetails() async {
    final snapshot = await _firestore
        .collection('Users')
        .doc(widget.departmentName)
        .collection('Students')
        .get();

    return snapshot.docs
        .map((doc) => {
              'Name': doc['Name'],
              'ID': doc['ID'],
              'fcmToken': doc['fcmToken'],
            })
        .toList();
  }

  Future<List<String>> _fetchMemberTokens() async {
    final snapshot = await _firestore
        .collection('Users')
        .doc(widget.departmentName)
        .collection('Students')
        .get();

    return snapshot.docs.map((doc) => doc['fcmToken'] as String).toList();
  }

  Future<void> _pickFile() async {
    final result = await FilePicker.platform.pickFiles(
      allowMultiple: false,
      type: FileType.custom,
      allowedExtensions: ['pdf', 'jpg', 'png', 'mp4', 'doc', 'docx'],
    );

    if (result != null) {
      final file = result.files.single;
      final filePath = file.path;
      final fileName = file.name;
      final fileExtension = file.extension ?? '';

      if (filePath != null) {
        final storageRef =
            _storage.ref().child('chat_files/$_chatRoomId/$fileName');
        final uploadTask = storageRef.putFile(File(filePath));

        uploadTask.snapshotEvents.listen((taskSnapshot) async {
          if (taskSnapshot.state == TaskState.success) {
            final fileUrl = await storageRef.getDownloadURL();
            final memberTokens = await _fetchMemberTokens();
            final messageRef = _firestore
                .collection('chats')
                .doc(_chatRoomId)
                .collection('messages')
                .doc();

            await messageRef.set({
              'ID': widget.name,
              'message': fileUrl,
              'timestamp': FieldValue.serverTimestamp(),
              'type': fileExtension,
              'recipient': memberTokens,
            });

            // Send notification
            for (String token in memberTokens) {
              await _sendNotification(token, fileUrl, fileExtension);
            }
          }
        });
      }
    }
  }

  Future<void> _sendNotification(
      String token, String fileUrl, String fileType) async {
    try {
      // Example FCM request
      print(
          'Sending notification to $token with URL $fileUrl and type $fileType');
    } catch (e) {
      print('Error sending notification: $e');
    }
  }

  Future<void> _openFile(String url) async {
    if (await canLaunch(url)) {
      await launch(url);
    } else {
      throw 'Could not launch $url';
    }
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          title: FutureBuilder<List<Map<String, dynamic>>>(
            future: _memberDetails,
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return Text('Loading...');
              }
              if (snapshot.hasError) {
                return Text('Error');
              }
              final memberDetails = snapshot.data ?? [];
              final studentIds =
                  memberDetails.map((member) => member['ID']).join(', ');
      
              return Text('${widget.departmentName} {$studentIds}',
                  style: TextStyle(color: Colors.white));
            },
          ),
          backgroundColor:  Color.fromARGB(255, 101, 8, 117),
          iconTheme: IconThemeData(color: Colors.white),
        ),
        body: Column(
          children: [
            Expanded(
              child: StreamBuilder<QuerySnapshot>(
                stream: _firestore
                    .collection('chats')
                    .doc(_chatRoomId)
                    .collection('messages')
                    .orderBy('timestamp', descending: true)
                    .snapshots(),
                builder: (context, snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return Center(child: CircularProgressIndicator());
                  }
      
                  if (snapshot.hasError) {
                    return Center(child: Text('Error: ${snapshot.error}'));
                  }
      
                  final messages = snapshot.data?.docs ?? [];
      
                  return ListView.builder(
                    reverse: true,
                    itemCount: messages.length,
                    itemBuilder: (context, index) {
                      final message =
                          messages[index].data() as Map<String, dynamic>;
                      final sender = message['ID'] ?? 'Unknown';
                      final text = message['message'] ?? '';
                      final type = message['type'] ?? 'text';
                      final timestamp = message['timestamp'] as Timestamp?;
                      final isMe = sender == widget.name;
      
                      // Format timestamp
                      final formattedTime = timestamp != null
                          ? DateFormat('hh:mm a').format(timestamp.toDate())
                          : 'Unknown Time';
      
                      return Align(
                        alignment:
                            isMe ? Alignment.centerLeft : Alignment.centerRight,
                        child: Padding(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 10.0, vertical: 10.0),
                          child: Container(
                            constraints: BoxConstraints(
                              maxWidth: MediaQuery.of(context).size.width * 0.65,
                            ),
                            padding: EdgeInsets.all(10),
                            decoration: BoxDecoration(
                              color: isMe
                                  ? Color.fromARGB(255, 101, 8, 117)
                                  : Color(0xff1b9bda),
                              borderRadius: BorderRadius.circular(20),
                            ),
                            child: Column(
                              crossAxisAlignment: isMe
                                  ? CrossAxisAlignment.start
                                  : CrossAxisAlignment.start,
                              children: [
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(
                                      sender,
                                      style: TextStyle(
                                        fontWeight: FontWeight.bold,
                                        color: Colors.white,
                                      ),
                                    ),
                                    Text(
                                      formattedTime,
                                      style: TextStyle(
                                        color: Colors.grey[300],
                                        fontSize: 12,
                                      ),
                                    ),
                                  ],
                                ),
                                SizedBox(height: 5),
                                type == 'pdf' || type == 'doc' || type == 'docx'
                                    ? GestureDetector(
                                        onTap: () => _openFile(text),
                                        child: Container(
                                          padding: EdgeInsets.all(10),
                                          decoration: BoxDecoration(
                                            color: Colors.white,
                                            borderRadius:
                                                BorderRadius.circular(8),
                                          ),
                                          child: Row(
                                            children: [
                                              Icon(Icons.attach_file,
                                                  color: Colors.black),
                                              SizedBox(width: 10),
                                              Text(
                                                'Open $type',
                                                style: TextStyle(
                                                  color: Colors.black,
                                                  decoration:
                                                      TextDecoration.underline,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      )
                                    : type == 'mp4'
                                        ? GestureDetector(
                                            onTap: () => Navigator.push(
                                              context,
                                              MaterialPageRoute(
                                                builder: (context) =>
                                                    VideoPlayerScreen(url: text),
                                              ),
                                            ),
                                            child: Container(
                                              padding: EdgeInsets.all(10),
                                              decoration: BoxDecoration(
                                                color: Colors.white,
                                                borderRadius:
                                                    BorderRadius.circular(8),
                                              ),
                                              child: Row(
                                                children: [
                                                  Icon(Icons.video_library,
                                                      color: Colors.black),
                                                  SizedBox(width: 10),
                                                  Text(
                                                    'Watch Video',
                                                    style: TextStyle(
                                                      color: Colors.black,
                                                      decoration: TextDecoration
                                                          .underline,
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          )
                                        : type == 'jpg' || type == 'png'
                                            ? Image.network(
                                                text,
                                                fit: BoxFit.cover,
                                              )
                                            : Text(
                                                text,
                                                style: TextStyle(
                                                    color: Colors.white),
                                              ),
                              ],
                            ),
                          ),
                        ),
                      );
                    },
                  );
                },
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Row(
                children: [
                  IconButton(
                    icon: Icon(
                      Icons.attach_file,
                      color: Color.fromARGB(255, 101, 8, 117),
                      size: 30,
                    ),
                    onPressed: _pickFile,
                  ),
                  Expanded(
                    child: TextField(
                      controller: _messageController,
                      decoration: InputDecoration(
                        hintText: 'Enter your message...',
                        fillColor: Color.fromARGB(255, 101, 8, 117),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(30),
                        ),
                      ),
                      maxLines: null,
                    ),
                  ),
                  IconButton(
                    icon: Icon(
                      Icons.send,
                      color: Color.fromARGB(255, 101, 8, 117),
                      size: 30,
                    ),
                    onPressed: () async {
                      final message = _messageController.text;
                      if (message.isNotEmpty) {
                        final memberTokens = await _fetchMemberTokens();
                        final messageRef = _firestore
                            .collection('chats')
                            .doc(_chatRoomId)
                            .collection('messages')
                            .doc();
      
                        await messageRef.set({
                          'ID': widget.name,
                          'message': message,
                          'timestamp': FieldValue.serverTimestamp(),
                          'type': 'text',
                          'recipient': memberTokens,
                        });
      
                        // Send notification
                        for (String token in memberTokens) {
                          await _sendNotification(token, message, 'text');
                        }
      
                        _messageController.clear();
                      }
                    },
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
