import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:college_app/teacher_profile/T_attendence.dart';

class SemesterAttendance extends StatefulWidget {
  final String id;

  SemesterAttendance({required this.id});

  @override
  _SemesterAttendanceState createState() => _SemesterAttendanceState();
}

class _SemesterAttendanceState extends State<SemesterAttendance> {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  Map<String, Map<String, List<Map<String, dynamic>>>> departmentsWithData = {};

  @override
  void initState() {
    super.initState();
    fetchData();
  }

  Future<void> fetchData() async {
    try {
      const List<String> departments = ['IT', 'Economic', 'Islamiat'];
      final Map<String, Map<String, List<Map<String, dynamic>>>>
          tempDepartments = {};

      for (String department in departments) {
        final Map<String, List<Map<String, dynamic>>> data = {};

        // Retrieve all teachers in this department
        final QuerySnapshot teachersSnapshot = await _firestore
            .collection('Users')
            .doc(department)
            .collection('Teachers')
            .where('ID', isEqualTo: widget.id)
            .get();

        if (teachersSnapshot.docs.isNotEmpty) {
          data['Teachers'] = teachersSnapshot.docs
              .map((doc) => doc.data() as Map<String, dynamic>)
              .toList();

          // Retrieve all students in this department if the teacher exists
          final QuerySnapshot studentsSnapshot = await _firestore
              .collection('Users')
              .doc(department)
              .collection('Students')
              .get();

          if (studentsSnapshot.docs.isNotEmpty) {
            data['Students'] = studentsSnapshot.docs
                .map((doc) => doc.data() as Map<String, dynamic>)
                .toList();
          }

          tempDepartments[department] = data;
        }
      }

      setState(() {
        departmentsWithData = tempDepartments;
      });

      if (departmentsWithData.isEmpty) {
        _showErrorDialog('No departments found with the specified teacher ID.');
      }
    } catch (e) {
      _showErrorDialog('Error fetching data: $e');
    }
  }

  void _showErrorDialog(String message) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Error'),
          content: Text(message),
          actions: <Widget>[
            TextButton(
              child: Text('OK'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: Color.fromARGB(255, 101, 8, 117),
          leading: IconButton(
            icon: Icon(Icons.arrow_back, color: Colors.white),
            onPressed: () {
              Navigator.of(context).pop();
            },
          ),
          title: Text(
            'Department',
            style: TextStyle(color: Colors.white),
          ),
        ),
        body: ListView(
          padding: EdgeInsets.all(10),
          children: departmentsWithData.keys.map((department) {
            final data = departmentsWithData[department] ?? {};
            final teacherData = data['Teachers'] ?? [];
            final studentData = data['Students'] ?? [];
            return _buildSolidColorContainer(
              color: _getColorForDepartment(department),
              department: department,
              teacherData: teacherData,
              studentData: studentData,
            );
          }).toList(),
        ),
      ),
    );
  }

  Widget _buildSolidColorContainer({
    required Color color,
    required String department,
    required List<Map<String, dynamic>> teacherData,
    required List<Map<String, dynamic>> studentData,
  }) {
    return GestureDetector(
      onTap: () {
        // Extract student IDs from studentData
        List<String> studentIds = studentData.map((data) {
          return data['ID']
              .toString(); // Assuming the student ID field is named 'ID'
        }).toList();

        Navigator.of(context).push(
          MaterialPageRoute(
            builder: (context) => AttendenceT(
              department: department,
              studentIds: studentIds, // Pass the list of student IDs here
              // Pass studentData if needed
            ),
          ),
        );
      },
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 15, horizontal: 30),
        child: Container(
          height: MediaQuery.of(context).size.height / 6,
          width: double.infinity,
          decoration: BoxDecoration(
            color: color,
            borderRadius: BorderRadius.circular(20),
          ),
          child: Row(
            children: <Widget>[
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Icon(
                  Icons.school, // Use the desired icon here
                  color: Colors.white,
                  size: 50,
                ),
              ),
              Expanded(
                child: Center(
                  child: Text(
                    '$department Attendance',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                    textAlign: TextAlign.center,
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Icon(
                  Icons.arrow_forward_ios, // Add a vector arrow icon
                  color: Colors.white,
                  size: 40,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Color _getColorForDepartment(String department) {
    // Define colors for departments or use a unique color generation approach
    switch (department) {
      case 'IT':
        return Color.fromARGB(255, 101, 8, 117);
      case 'Islamiat':
        return Color.fromARGB(255, 101, 8, 117);
      case 'Economic':
        return Color.fromARGB(255, 101, 8, 117);
      default:
        return Colors.grey;
    }
  }
}
