import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class TimetableDepartments extends StatefulWidget {
  @override
  _TimetableDepartmentsState createState() => _TimetableDepartmentsState();
}

class _TimetableDepartmentsState extends State<TimetableDepartments>
    with SingleTickerProviderStateMixin {
  final List<String> departments = ['IT', 'Economic', 'Islamiat'];
  late AnimationController _controller;
  late Animation<Offset> _animation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: Duration(milliseconds: 800),
      vsync: this,
    );

    _animation = Tween<Offset>(
      begin: Offset(-1.0, 0.0), // Start off-screen
      end: Offset(0.0, 0.0),    // End at the original position
    ).animate(
      CurvedAnimation(
        parent: _controller,
        curve: Curves.easeInOut,
      ),
    );

    // Start the animation when the screen is loaded
    _controller.forward();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          title: Text('Select Department',style: TextStyle(color: Colors.white,),),
          iconTheme: IconThemeData(color: Colors.white),
          backgroundColor: Color.fromARGB(255, 101, 8, 117),
        ),
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: departments.map((department) {
              return Padding(
                padding: const EdgeInsets.all(8.0),
                child: GestureDetector(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => TimetableT(department: department),
                      ),
                    );
                  },
                  child: AnimatedBuilder(
                    animation: _controller,
                    builder: (context, child) {
                      return SlideTransition(
                        position: _animation,
                        child: Container(
                          width: 320, // Increased width
                          height: 130,
                          decoration: BoxDecoration(
                            color:  Color.fromARGB(255, 101, 8, 117), // Updated color
                            borderRadius: BorderRadius.circular(25),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black26,
                                blurRadius: 8,
                                offset: Offset(0, 4),
                              ),
                            ],
                          ),
                          child: Center(
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceAround,
                              children: [
                                Icon(
                                  Icons.school, // Example icon
                                  color: Colors.white,
                                  size: 35,
                                ),
                                SizedBox(width: 8),
                                Text(
                                  department,
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 20,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                SizedBox(width: 8),
                                Icon(
                                  Icons.arrow_forward_ios,
                                  color: Colors.white,
                                  size: 24,
                                ),
                              ],
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                ),
              );
            }).toList(),
          ),
        ),
      ),
    );
  }
}
class TimetableT extends StatefulWidget {
  final String department;

  TimetableT({required this.department});

  @override
  _TimetableTState createState() => _TimetableTState();
}

class _TimetableTState extends State<TimetableT>
    with SingleTickerProviderStateMixin {
  final List<String> days = ['Mon', 'Tues', 'Wed', 'Thurs', 'Fri', 'Sat', 'Sun'];

  late AnimationController _animationController;
  late Animation<Offset> _dropdownAnimation;
  late List<Animation<Offset>> _rowAnimations;

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      duration: Duration(seconds: 1),
      vsync: this,
    );

    _dropdownAnimation = Tween<Offset>(
      begin: Offset(0, -1),
      end: Offset(0, 0),
    ).animate(
      CurvedAnimation(
        parent: _animationController,
        curve: Curves.easeOut,
      ),
    );

    _rowAnimations = days.map((day) {
      int index = days.indexOf(day);
      return Tween<Offset>(
        begin: Offset(0, 1),
        end: Offset(0, 0),
      ).animate(
        CurvedAnimation(
          parent: _animationController,
          curve: Interval(0.1 * index, 1.0, curve: Curves.easeOut),
        ),
      );
    }).toList();

    _animationController.forward();
  }

  Future<Map<String, List<Map<String, String>>>> _fetchTimetableData() async {
    Map<String, List<Map<String, String>>> timetableData = {};

    for (String day in days) {
      DocumentSnapshot docSnapshot = await FirebaseFirestore.instance
          .collection('TeacherTimetable')
          .doc(widget.department) // Use the selected department
          .collection('Days')
          .doc(day)
          .get();

      if (docSnapshot.exists) {
        try {
          Map<String, dynamic> data =
          docSnapshot.data() as Map<String, dynamic>;

          List<dynamic> subjectsList = data['subjects'] as List<dynamic>? ?? [];

          timetableData[day] = subjectsList.map((dynamic subject) {
            if (subject is Map<String, dynamic>) {
              return {
                'subject': subject['subject'] as String? ?? 'No Subject',
                'time': subject['time'] as String? ?? 'No Time',
              };
            } else {
              return {
                'subject': 'No Subject',
                'time': 'No Time',
              };
            }
          }).toList();
        } catch (e) {
          print('Error parsing data for $day: $e');
          timetableData[day] = [
            {'subject': 'Error', 'time': 'Error'}
          ];
        }
      } else {
        timetableData[day] = [
          {'subject': 'No Subject', 'time': 'No Time'},
          {'subject': 'No Subject', 'time': 'No Time'},
          {'subject': 'No Subject', 'time': 'No Time'},
        ];
      }
    }
    return timetableData;
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          title: Text(
            'Timetable for ${widget.department}', // Display selected department
            style: TextStyle(color: Colors.white),
          ),
          backgroundColor: Color.fromARGB(255, 101, 8, 117),
          iconTheme: IconThemeData(
            color: Colors.white,
          ),
        ),
        body: Center(
          child: SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(height: 16), // Space between department name and table
                  FutureBuilder<Map<String, List<Map<String, String>>>>(
                    future: _fetchTimetableData(),
                    builder: (context, snapshot) {
                      if (snapshot.connectionState == ConnectionState.waiting) {
                        return Center(child: CircularProgressIndicator());
                      } else if (snapshot.hasError) {
                        return Center(child: Text('Error loading timetable data'));
                      } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
                        return Center(child: Text('No timetable data available'));
                      }

                      final timetableData = snapshot.data!;
                      return Container(
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(12),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black26,
                              blurRadius: 8,
                              offset: Offset(0, 4),
                            ),
                          ],
                        ),
                        child: Table(
                          columnWidths: {
                            0: FlexColumnWidth(1.0), // Days column
                            1: FlexColumnWidth(2.0), // Subjects column
                            2: FlexColumnWidth(1.5), // Times column
                          },
                          children: [
                            TableRow(
                              decoration: BoxDecoration(
                                color: Color.fromARGB(255, 101, 8, 117), // Header row color
                              ),
                              children: [
                                Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: Text(
                                    'Day',
                                    style: TextStyle(
                                      fontSize: 16,
                                      fontWeight: FontWeight.bold,
                                      color: Colors.white,
                                    ),
                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: Text(
                                    'Subject',
                                    style: TextStyle(
                                      fontSize: 16,
                                      fontWeight: FontWeight.bold,
                                      color: Colors.white,
                                    ),
                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: Text(
                                    'Time',
                                    style: TextStyle(
                                      fontSize: 16,
                                      fontWeight: FontWeight.bold,
                                      color: Colors.white,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            for (var day in days)
                              ...[
                                for (var i = 0; i < timetableData[day]!.length; i++)
                                  TableRow(
                                    decoration: BoxDecoration(
                                      color: i == 0 ? Color.fromARGB(255, 101, 8, 117).withOpacity(0.6) : Colors.white,
                                    ),
                                    children: [
                                      Padding(
                                        padding: const EdgeInsets.all(8.0),
                                        child: Text(
                                          i == 0 ? day : '',  // Display 'day' only for the first row
                                          style: TextStyle(
                                            fontSize: 14,
                                            fontWeight: FontWeight.bold,
                                            color: Colors.black,
                                          ),
                                        ),
                                      ),
                                      Padding(
                                        padding: const EdgeInsets.all(8.0),
                                        child: Text(
                                          timetableData[day]![i]['subject']!,
                                          style: TextStyle(
                                            fontSize: 14,
                                            color: Colors.black,
                                          ),
                                        ),
                                      ),
                                      Padding(
                                        padding: const EdgeInsets.all(8.0),
                                        child: Text(
                                          timetableData[day]![i]['time']!,
                                          style: TextStyle(
                                            fontSize: 14,
                                            color: Colors.black,
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                              ],

                          ],
                        ),
                      );
                    },
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
