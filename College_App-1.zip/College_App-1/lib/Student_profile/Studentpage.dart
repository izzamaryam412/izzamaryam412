import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:curved_navigation_bar/curved_navigation_bar.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path/path.dart' as path;

import 'Attendance.dart';
import 'Community.dart';
import 'Courses.dart';
import 'Event.dart';
import 'Notifications.dart';
import 'Timetable.dart';

class Studentpage extends StatefulWidget {
  final String name;
  final String id;
  final String department;
  Studentpage({required this.name, required this.id, required this.department});

  @override
  _StudentpageState createState() => _StudentpageState();
}

class _StudentpageState extends State<Studentpage> {
  int _selectedIndex = 0;
  File? _image;
  String? _imageUrl;
  bool _isLoading = false; // Loading state variable
  final ImagePicker _imagePicker = ImagePicker();
  final FirebaseStorage _firebaseStorage = FirebaseStorage.instance;

  late PageController _pageController;

  @override
  void initState() {
    super.initState();
    _pageController = PageController(initialPage: _selectedIndex);
    _fetchProfileImage(); // Fetch the profile image when the widget is initialized
  }

  Future<void> _uploadImage(File image) async {
    try {
      setState(() {
        _isLoading = true;
      });

      String userId = widget.id;
      String department = widget.department;
      String role = 'Students';

      // Construct the storage path including department and role
      final storageRef = FirebaseStorage.instance
          .ref()
          .child('images/$department/$role/$userId.jpg');

      // Upload the new image
      final uploadTask = storageRef.putFile(image);
      final snapshot = await uploadTask.whenComplete(() => {});
      final downloadUrl = await snapshot.ref.getDownloadURL();

      // Save image URL in Firestore
      await FirebaseFirestore.instance
          .collection('images')
          .doc(department)
          .collection(role)
          .doc(userId)
          .set({'imageUrl': downloadUrl}, SetOptions(merge: true));

      setState(() {
        _imageUrl = downloadUrl;
        _isLoading = false;
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Image uploaded successfully!')),
      );
    } catch (e) {
      setState(() {
        _isLoading = false;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to upload image: $e')),
      );
    }
  }

  Future<void> _fetchProfileImage() async {
    setState(() {
      _isLoading = true;
    });

    try {
      String userId = widget.id;
      String department = widget.department;
      String role = 'Students';

      DocumentSnapshot userDoc = await FirebaseFirestore.instance
          .collection('images')
          .doc(department)
          .collection(role)
          .doc(userId)
          .get();

      if (userDoc.exists) {
        setState(() {
          _imageUrl = userDoc.get('imageUrl') as String?;
          _isLoading = false;
        });
      } else {
        setState(() {
          _imageUrl = null;
          _isLoading = false;
        });
      }
    } catch (e) {
      print('Error fetching profile image: $e');
      setState(() {
        _isLoading = false;
      });
    }
  }

  Future<void> getImageFromGallery() async {
    final pickedFile =
        await _imagePicker.pickImage(source: ImageSource.gallery);
    setState(() {
      if (pickedFile != null) {
        _image = File(pickedFile.path);
        if (_image != null) {
          _uploadImage(_image!);
        }
      }
    });
  }

  Future<void> getImageFromCamera() async {
    final pickedFile = await _imagePicker.pickImage(source: ImageSource.camera);
    setState(() {
      if (pickedFile != null) {
        _image = File(pickedFile.path); // Verify if this path is valid
        if (_image != null) {
          _uploadImage(_image!);
        }
      }
    });
  }

  Future<void> showOptions() async {
    showCupertinoModalPopup(
      context: context,
      builder: (context) => CupertinoActionSheet(
        actions: [
          Container(
            color: Color(0xff1b9bda),
            child: CupertinoActionSheetAction(
              child: Text('Gallery', style: TextStyle(color: Colors.white)),
              onPressed: () {
                Navigator.of(context).pop();
                getImageFromGallery();
              },
            ),
          ),
          Container(
            color: Color(0xff1b9bda),
            child: CupertinoActionSheetAction(
              child: Text('Camera', style: TextStyle(color: Colors.white)),
              onPressed: () {
                Navigator.of(context).pop();
                getImageFromCamera();
              },
            ),
          ),
        ],
      ),
    );
  }

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
    _pageController.animateToPage(
      index,
      duration: Duration(milliseconds: 300),
      curve: Curves.easeInOut,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: PageView(
        controller: _pageController,
        onPageChanged: (index) {
          setState(() {
            _selectedIndex = index;
          });
        },
        children: [
          HomePage(
            department: widget.department,
            id: widget.id,
            name: widget.name,
            image: _image,
            onImagePick: (ImageSource source) => showOptions(),
            onImageUpload: () {
              if (_image != null) {
                _uploadImage(_image!);
              } else {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('No image selected for upload.')),
                );
              }
            },
            imageUrl: _imageUrl,
            isLoading: _isLoading,
          ),
          Community(
            name: widget.name,
            id: widget.id,
            department: widget.department,
          ),
          NotificationPage(department: widget.department),
        ],
      ),
      bottomNavigationBar: CurvedNavigationBar(
        index: _selectedIndex,
        items: <Widget>[
          Icon(Icons.home, size: 30, color: Colors.white),
          Icon(Icons.group, size: 30, color: Colors.white),
          Icon(Icons.notifications, size: 30, color: Colors.white),
        ],
        color: Color(0xff1b9bda), // Background color of the navigation bar
        buttonBackgroundColor:
        Color(0xff1b9bda), // Background color of the active button
        backgroundColor:
            Colors.transparent, // Background color of the navigation bar area
        animationCurve: Curves.easeInOut,
        animationDuration: Duration(milliseconds: 300),
        onTap: _onItemTapped,
      ),
    );
  }
}

class HomePage extends StatefulWidget {
  final String name;
  final String id;
  final File? image;
  final String? imageUrl;
  final String department;
  final Future<void> Function(ImageSource) onImagePick;
  final VoidCallback onImageUpload;
  final bool isLoading; // Add this line

  HomePage({
    required this.department,
    required this.id,
    required this.name,
    required this.image,
    required this.onImagePick,
    required this.onImageUpload,
    required this.imageUrl,
    required this.isLoading, // Add this line
  });

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  bool _isLoading = false;
  String? _imageUrl;

  // Call this method whenever the image is being uploaded
  void _startLoading() {
    setState(() {
      _isLoading = true;
    });
  }

  // Call this method when the image upload is completed
  void _stopLoading() {
    setState(() {
      _isLoading = false;
    });
  }

  Future<void> _deleteImage() async {
    try {
      setState(() {
        _isLoading = true;
      });

      String userId = widget.id;
      String department = widget.department;
      String role = 'Students';

      final storageRef = FirebaseStorage.instance
          .ref()
          .child('images/$department/$role/$userId.jpg');

      await storageRef.delete();
      print('Image deleted from Firebase Storage');

      await FirebaseFirestore.instance
          .collection('images')
          .doc(department)
          .collection(role)
          .doc(userId)
          .delete();

      print('Image data deleted from Firestore');

      setState(() {
        _imageUrl = null;
        _isLoading = false;
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Image deleted successfully!')),
      );
    } catch (e) {
      setState(() {
        _isLoading = false;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to delete image: $e')),
      );
    }
  }

  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: Stack(
          children: [
            buildBackground(),
            Column(
              children: [
                Container(
                  margin: EdgeInsets.only(top: 45, left: 40),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      GestureDetector(
                          onTap: () {
                            showDialog(
                              context: context,
                              builder: (context) =>
                                  AlertDialog(
                                    title: Text('Select Image',style: TextStyle(color: Color(0xff1b9bda)),),
                                    actions: [
                                      TextButton(
                                        onPressed: () async {
                                          Navigator.pop(context);
                                          await _deleteImage();
                                        },
                                        child: Text('Delete',
                                            style: TextStyle(color: Colors.red)),
                                      ),
                                      TextButton(
                                        onPressed: () {
                                          Navigator.pop(context);
                                        },
                                        child: Text('Close',style: TextStyle(color: Color(0xff1b9bda)),),
                                      ),
                                      TextButton(
                                        onPressed: () {
                                          Navigator.pop(context);
                                          widget.onImagePick(ImageSource.gallery);
                                        },
                                        child: Text('Update',style: TextStyle(color: Color(0xff1b9bda)),),
                                      ),
                                    ],
                                  ),
                            );
                          },
                          child: CircleAvatar(
                            radius: 55,
                            backgroundColor: Colors.grey[300],
                            child: widget.isLoading
                                ? CircularProgressIndicator()
                                : widget.imageUrl != null
                                ? ClipOval(
                              child: Image.network(
                                '${widget.imageUrl}?timestamp=${DateTime
                                    .now()
                                    .millisecondsSinceEpoch}',
                                fit: BoxFit.cover,
                                width: 110,
                                height: 110,
                                errorBuilder:
                                    (context, error, stackTrace) {
                                  print('Image load error: $error');
                                  return Icon(Icons.person,
                                      size: 60, color: Colors.white);
                                },
                              ),
                            )
                                : Icon(Icons.person,
                                size: 60, color: Colors.white),
                          )),
                      Expanded(
                        child: Column(
                          children: [
                            Text(
                              'Name: ${widget.name}',
                              style: TextStyle(
                                fontSize: 20,
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            Text(
                              'Roll no: ${widget.id}',
                              style: TextStyle(
                                fontSize: 17,
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                              ),
                              textAlign: TextAlign.center,
                            ),
                            Text(
                              'Department: ${widget.department}',
                              style: TextStyle(
                                fontSize: 17,
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                              ),
                            )
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                SizedBox(height: 10),
                Expanded(
                  child: SingleChildScrollView(
                    child: buildGrid(context),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget buildBackground() {
    return Container(
      width: double.infinity,
      height: double.infinity,
      color: Color(0xFFF0F8FF),
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.only(left: 8, right: 8),
            child: Container(
                height: 260,
                decoration: BoxDecoration(
                    color: Color(0xff1b9bda),
                    borderRadius: BorderRadius.only(
                        bottomLeft: Radius.circular(50),
                        bottomRight: Radius.circular(50)),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.8), // Shadow color
                        blurRadius: 16, // Spread of the shadow
                        offset: Offset(0, 4),
                      )
                    ])),
          ),
        ],
      ),
    );
  }

  Widget buildGrid(BuildContext context) {
    return Container(
      padding: EdgeInsets.only(top: 160, left: 20, right: 20, bottom: 9),
      child: GridView.count(
        crossAxisCount: 2,
        crossAxisSpacing: 10,
        mainAxisSpacing: 10,
        shrinkWrap: true,
        physics: NeverScrollableScrollPhysics(),
        children: [
          buildGridItem(
              context,
              Icons.add_task,
              'Attendance',
              Attendance(
                id: widget.id,
                department: widget.department,
              )),
          buildGridItem(
              context,
              Icons.add_task,
              'Timetable',
              Timetable(
                department: widget.department,
              )),
          buildGridItem(context, Icons.event, 'Events', Event()),
          buildGridItem(context, Icons.calendar_month, 'Courses', Courses(department: widget.department,)),
        ],
      ),
    );
  }

  Widget buildGridItem(BuildContext context, IconData icon, String title,
      Widget page) {
    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => page),
        );
      },
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(15),
          boxShadow: [
            BoxShadow(
              color: Colors.black26,
              blurRadius: 10,
              offset: Offset(0, 5),
            ),
          ],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: Color(0xff1b9bda), size: 50),
            Text(
              title,
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: Color(0xff1b9bda),
              ),
            ),
          ],
        ),
      ),
    );
  }
}