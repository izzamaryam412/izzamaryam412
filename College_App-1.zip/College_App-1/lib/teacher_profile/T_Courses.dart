import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class T_Courses extends StatefulWidget {
  @override
  _CoursesStudentState createState() => _CoursesStudentState();
}

class _CoursesStudentState extends State<T_Courses> {
  final List<Map<String, String>> departments = [
    {'name': 'Economics',},
    {'name': 'IT',},
    {'name': 'Islamiat',},
  ];

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: SafeArea(
        child: Scaffold(
          appBar: AppBar(
            backgroundColor:Color.fromARGB(255, 101, 8, 117),
            title: Text(
              'Select Department',
              style: TextStyle(color: Colors.white),
            ),
            leading: IconButton(
              icon: Icon(Icons.arrow_back),
              onPressed: () {
                Navigator.pop(context);
              },
            ),
            iconTheme: IconThemeData(
              color: Colors.white,
            ),
          ),
          body: Padding(
            padding: const EdgeInsets.all(16.0),
            child: GridView.builder(
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2, // Two departments per row
                crossAxisSpacing: 16,
                mainAxisSpacing: 16,
                childAspectRatio: 1, // Square blocks
              ),
              itemCount: departments.length,
              itemBuilder: (context, index) {
                return DepartmentCard(
                  departmentName: departments[index]['name']!,
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => SemesterView(
                          department: departments[index]['name']!,
                          semesters: {
                            'Semester 1': [],
                            'Semester 2': [],
                            'Semester 3': [],
                            'Semester 4': [],
                            'Semester 5': [],
                            'Semester 6': [],
                            'Semester 7': [],
                            'Semester 8': [],
                          },
                        ),
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ),
      ),
    );
  }
}

class DepartmentCard extends StatelessWidget {
  final String departmentName;
  final VoidCallback onTap;

  DepartmentCard({
    required this.departmentName,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Card(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
        elevation: 8,
        shadowColor: Color.fromARGB(255, 101, 8, 117),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.school, // You can customize this icon based on the department
              size: 50,
              color: Color.fromARGB(255, 101, 8, 117),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Text(
                departmentName,
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 18,
                  color: Color.fromARGB(255, 101, 8, 117),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class SemesterView extends StatelessWidget {
  final Map<String, List<Map<String, String>>> semesters;
  final String department;

  SemesterView({required this.semesters, required this.department});

  @override
  Widget build(BuildContext context) {
    List<String> semesterKeys = semesters.keys.toList();
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: Color.fromARGB(255, 101, 8, 117),
          title: Text(
            '$department - Semesters',
            style: TextStyle(color: Colors.white),
          ),
          iconTheme: IconThemeData(color: Colors.white),
          leading: IconButton(
            icon: Icon(Icons.arrow_back),
            onPressed: () {
              Navigator.pop(context);
            },
          ),
        ),
        body: ListView.builder(
          itemCount: semesterKeys.length,
          itemBuilder: (context, index) {
            String semester = semesterKeys[index];
            return Card(
              elevation: 6,
              shadowColor: Color.fromARGB(255, 101, 8, 117),
              margin: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              child: ListTile(
                title: Text(
                  semester,
                  style: TextStyle(
                    color: Color.fromARGB(255, 101, 8, 117),
                    fontWeight: FontWeight.bold,
                  ),
                ),
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => SemesterSubjectsView(
                        semester: semester,
                        department: department,
                      ),
                    ),
                  );
                },
              ),
            );
          },
        ),
      ),
    );
  }
}

class SemesterSubjectsView extends StatelessWidget {
  final String semester;
  final String department;

  SemesterSubjectsView({required this.semester, required this.department});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: Color.fromARGB(255, 101, 8, 117),
          title: Text(
            '$department - $semester',
            style: TextStyle(color: Colors.white),
          ),
          iconTheme: IconThemeData(color: Colors.white),
        ),
        body: StreamBuilder<QuerySnapshot>(
          stream: FirebaseFirestore.instance
              .collection('Subjects')
              .doc(department)
              .collection(semester)
              .snapshots(),
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return Center(child: CircularProgressIndicator());
            }

            if (snapshot.hasError) {
              return Center(child: Text('Error fetching subjects'));
            }

            if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
              return Center(child: Text('No subjects available.'));
            }

            List<DocumentSnapshot> subjects = snapshot.data!.docs;

            return ListView.builder(
              itemCount: subjects.length,
              itemBuilder: (context, index) {
                var subjectData =
                subjects[index].data() as Map<String, dynamic>;

                return Card(
                  elevation: 6,
                  shadowColor: Color.fromARGB(255, 101, 8, 117),
                  margin: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  child: ListTile(
                    title: Text(subjectData['name'] ?? 'No name'),
                    subtitle: Text(subjectData['department'] ?? 'No department'),
                    leading: subjectData['image'] != null
                        ? GestureDetector(
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => FullScreenImageView(
                              imagePath: subjectData['image'] ?? '',
                            ),
                          ),
                        );
                      },
                      child: Image.network(
                        subjectData['image'],
                        width: 50,
                        height: 50,
                        fit: BoxFit.cover,
                      ),
                    )
                        : null,
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => SubjectView(
                            semester: semester,
                            subject: subjectData['name'] ?? 'No name',
                            imagePath: subjectData['image'] ?? '',
                            department: subjectData['department'] ?? 'Unknown',
                          ),
                        ),
                      );
                    },
                  ),
                );

              },
            );
          },
        ),
      ),
    );
  }
}

class SubjectView extends StatelessWidget {
  final String department;
  final String semester;
  final String subject;
  final String imagePath;

  SubjectView({
    required this.department,
    required this.semester,
    required this.subject,
    required this.imagePath,
  });

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          title: Text(subject, style: TextStyle(color: Colors.white)),
          backgroundColor: Color.fromARGB(255, 101, 8, 117),
          iconTheme: IconThemeData(
            color: Colors.white,
          ),
        ),
        body: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Text(
                '$department - $semester',
                style: TextStyle(
                  color: Color.fromARGB(255, 101, 8, 117),
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            SizedBox(height: 20),
            imagePath.isNotEmpty
                ? GestureDetector(
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => FullScreenImageView(
                      imagePath: imagePath,
                    ),
                  ),
                );
              },
              child: Image.network(
                imagePath,
                height: 200,
                fit: BoxFit.cover,
              ),
            )
                : Container(),
            SizedBox(height: 20),
            Text(
              subject,
              style: TextStyle(
                color: Color.fromARGB(255, 101, 8, 117),
                fontSize: 22,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class FullScreenImageView extends StatelessWidget {
  final String imagePath;

  FullScreenImageView({required this.imagePath});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
           iconTheme: IconThemeData(
             color: Colors.white,
           ),
          backgroundColor: Color.fromARGB(255, 101, 8, 117),
        ),
        backgroundColor: Colors.black,
        body: Center(
          child: GestureDetector(
            onTap: () {
              Navigator.pop(context);
            },
            child: Image.network(
              imagePath,
              fit: BoxFit.contain, // Adjust this to your preference
              width: double.infinity,
              height: double.infinity,
            ),
          ),
        ),
      ),
    );
  }
}
