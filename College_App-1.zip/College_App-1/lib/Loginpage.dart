import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:college_app/Student_profile/Studentpage.dart';
import 'package:college_app/teacher_profile/page_teacher.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';

class Loginpage extends StatefulWidget {
  @override
  _LoginpageState createState() => _LoginpageState();
}

class _LoginpageState extends State<Loginpage> {
  final _formKey = GlobalKey<FormState>();
  bool _passwordVisible = false;
  final idController = TextEditingController();
  final nameController = TextEditingController();
  final passwordController = TextEditingController();

  Future<void> login(BuildContext context) async {
    try {
      // Retrieve entered values
      String enteredId = idController.text.trim();
      String enteredPassword = passwordController.text.trim();
      String enteredName = nameController.text.trim();

      print("Entered ID: $enteredId");
      print("Entered Password: $enteredPassword");
      print("Entered Name: $enteredName");

      // List of departments
      List<String> departments = ['Economic', 'IT', 'Islamiat'];
      bool userFound = false;
      String? userDepartment;

      for (String department in departments) {
        // Check in Students collection
        CollectionReference studentsCollectionRef = FirebaseFirestore.instance
            .collection('Users')
            .doc(department)
            .collection('Students');

        QuerySnapshot studentQuerySnapshot = await studentsCollectionRef
            .where('ID', isEqualTo: enteredId)
            .where('Password', isEqualTo: enteredPassword)
            .get();

        if (studentQuerySnapshot.docs.isNotEmpty) {
          // Filter documents locally by name
          DocumentSnapshot? matchingDoc;
          for (var doc in studentQuerySnapshot.docs) {
            if (doc['Name'] == enteredName) {
              matchingDoc = doc;
              userFound = true;
              userDepartment = department; // Set the department
              break;
            }
          }

          if (userFound) {
            String role = matchingDoc?['Role'] ?? 'Unknown';

            // Retrieve and update FCM token
            String? fcmToken = await FirebaseMessaging.instance.getToken();
            if (fcmToken != null) {
              await FirebaseFirestore.instance
                  .collection('Users')
                  .doc(department)
                  .collection('Students')
                  .doc(matchingDoc?.id)
                  .update({'fcmToken': fcmToken});
            }

            // Navigate based on user role
            if (role == 'Student') {
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(
                  builder: (context) => Studentpage(
                      name: enteredName, id: enteredId, department: department),
                ),
              );
            } else {
              showDialog(
                context: context,
                builder: (BuildContext context) {
                  return AlertDialog(
                    content:
                    Text("Unexpected role found. Please contact support."),
                  );
                },
              );
            }
            break; // Stop searching once user is found
          }
        }

        // Check in Teachers collection
        CollectionReference teachersCollectionRef = FirebaseFirestore.instance
            .collection('Users')
            .doc(department)
            .collection('Teachers');

        QuerySnapshot teacherQuerySnapshot = await teachersCollectionRef
            .where('ID', isEqualTo: enteredId)
            .where('Password', isEqualTo: enteredPassword)
            .get();

        if (teacherQuerySnapshot.docs.isNotEmpty) {
          // Filter documents locally by name
          DocumentSnapshot? matchingDoc;
          for (var doc in teacherQuerySnapshot.docs) {
            if (doc['Name'] == enteredName) {
              matchingDoc = doc;
              userFound = true;
              userDepartment = department; // Set the department
              break;
            }
          }

          if (userFound) {
            String role = matchingDoc?['Role'] ?? 'Unknown';

            // Retrieve and update FCM token
            String? fcmToken = await FirebaseMessaging.instance.getToken();
            if (fcmToken != null) {
              await FirebaseFirestore.instance
                  .collection('Users')
                  .doc(department)
                  .collection('Teachers')
                  .doc(matchingDoc?.id)
                  .update({'fcmToken': fcmToken});
            }

            // Navigate based on user role
            if (role == 'Teacher') {
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(
                  builder: (context) => TeacherPage(
                      name: enteredName, id: enteredId, department: department),
                ),
              );
            } else {
              showDialog(
                context: context,
                builder: (BuildContext context) {
                  return AlertDialog(
                    content:
                    Text("Unexpected role found. Please contact support."),
                  );
                },
              );
            }
            break; // Stop searching once user is found
          }
        }
      }

      if (!userFound) {
        // Handle case where no matching documents were found
        showDialog(
          context: context,
          builder: (BuildContext context) {
            return AlertDialog(
              content: Text("Invalid ID, Password, or Name"),
            );
          },
        );
      } else {
        // Use the department information if needed
        print("User found in department: $userDepartment");
      }
    } catch (e) {
      print("Error during Firestore query: $e");
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: $e')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        resizeToAvoidBottomInset: true,
        body: SingleChildScrollView(
          child: Stack(
            children: [
              Container(
                width: double.infinity,
                height: 600,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      Color(0xff1b9bda),
                      Color.fromARGB(255, 101, 8, 117),// Second color
                    ],
                    begin: Alignment.topLeft,           // Start position of the gradient
                    end: Alignment.topRight,         // End position of the gradient
                  ),
                  borderRadius: BorderRadius.only(
                    bottomRight: Radius.elliptical(500, 500),
                  ),
                ),
              ),
              Column(
                children: [
                  SizedBox(height: 150),
                  Text(
                    'Login',
                    style: TextStyle(
                      fontSize: 34,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                  SizedBox(height: 30),
                  Container(
                    margin: EdgeInsets.symmetric(horizontal: 16),
                    padding: EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(15),
                      color: Colors.white,
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black26,
                          blurRadius: 10,
                          offset: Offset(0, 5),
                        ),
                      ],
                    ),
                    child: Form(
                      key: _formKey,
                      child: Column(
                        children: [
                          Padding(
                            padding: const EdgeInsets.fromLTRB(12, 5, 12, 5),
                            child: TextFormField(
                              controller: nameController,
                              decoration: InputDecoration(
                                labelText: 'Name',
                                enabledBorder: UnderlineInputBorder(
                                  borderSide: BorderSide(color: Colors.blue),
                                ),
                                suffixIcon: Icon(Icons.person,
                                    color: Color(0xff1b9bda)),
                                labelStyle: TextStyle(color: Color(0xff1b9bda)),
                              ),
                              style: TextStyle(color: Color(0xff1b9bda)),
                              validator: (value) {
                                if (value == null || value.isEmpty) {
                                  return 'Please enter your Name';
                                }
                                return null;
                              },
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.fromLTRB(12, 5, 12, 5),
                            child: TextFormField(
                              controller: idController,
                              decoration: InputDecoration(
                                labelText: 'User ID',
                                enabledBorder: UnderlineInputBorder(
                                  borderSide: BorderSide(color: Colors.blue),
                                ),
                                suffixIcon:
                                Icon(Icons.email, color: Color(0xff1b9bda)),
                                labelStyle: TextStyle(color: Color(0xff1b9bda)),
                              ),
                              style: TextStyle(color: Color(0xff1b9bda)),
                              validator: (value) {
                                if (value == null || value.isEmpty) {
                                  return 'Please enter your ID';
                                }
                                return null;
                              },
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.fromLTRB(12, 5, 12, 5),
                            child: TextFormField(
                              controller: passwordController,
                              decoration: InputDecoration(
                                labelText: 'Password',
                                enabledBorder: UnderlineInputBorder(
                                  borderSide: BorderSide(color: Colors.blue),
                                ),
                                suffixIcon: IconButton(
                                  icon: Icon(
                                    _passwordVisible
                                        ? Icons.visibility
                                        : Icons.visibility_off,
                                    color: Color(0xff1b9bda),
                                  ),
                                  onPressed: () {
                                    setState(() {
                                      _passwordVisible = !_passwordVisible;
                                    });
                                  },
                                ),
                                labelStyle: TextStyle(color: Color(0xff1b9bda)),
                              ),
                              obscureText: !_passwordVisible,
                              style: TextStyle(color: Color(0xff1b9bda)),
                              validator: (value) {
                                if (value == null || value.isEmpty) {
                                  return 'Please enter your Password';
                                }
                                return null;
                              },
                            ),
                          ),
                          SizedBox(height: 20),
                          SizedBox(
                            width: double.infinity,
                            child: Padding(
                              padding: const EdgeInsets.only(left: 12,right: 12),
                              child: Container(
                                decoration: BoxDecoration(
                                  gradient: LinearGradient(
                                    colors: [
                                      Color.fromARGB(255, 101, 8, 117), // First color
                                      Color(0xff1b9bda),                // Second color
                                    ],
                                    begin: Alignment.topLeft,
                                    end: Alignment.bottomRight,
                                  ),
                                  borderRadius: BorderRadius.circular(10),
                                ),
                                child: ElevatedButton(
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: Colors.transparent, // Make button background transparent
                                    shadowColor: Colors.transparent,
                                    padding: EdgeInsets.symmetric(vertical: 13),
                                  ),
                                  onPressed: () {
                                    if (_formKey.currentState?.validate() ??
                                        false) {
                                      login(context);
                                    }
                                  },
                                  child: Text(
                                    'Login',
                                    style: TextStyle(fontSize: 18,color: Colors.white),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
